import { useEffect, useMemo, useRef, useState } from 'react';
import { Capacitor, registerPlugin } from '@capacitor/core';
import {
  BookOpen,
  Brain,
  Bot,
  Search,
  Languages,
  Settings as SettingsIcon,
  Send,
  Mic,
  Volume2,
  Star,
  Download,
  Upload,
  Trash2,
  Wifi,
  WifiOff,
  Square,
  RotateCcw,
  Check,
  Clock3,
  RefreshCw,
  Copy,
  BarChart3,
} from 'lucide-react';

import { DIALECT_FILTERS, getLangCode } from './data';
import {
  initLanguageBank,
  getBankItems,
  searchBank,
  saveBankItem,
  exportBank,
  importBank,
} from './languageBank';

import {
  chat,
  configuredProviders,
  providerLabel,
  testProvider,
  discoverCustomModels,
  discoverAllConfiguredModels,
  type DiscoveredModel,
  inspectCustomEndpoint,
} from './ai';

import {
  getLogs,
  addLog,
  clearLogs,
  getNativeLogcat,
} from './diagnostics';

import {
  listenSpeech,
  stopSpeech,
  speechAvailability,
} from './speech';

import {
  localChat,
  localModelStatus,
  loadLocalModel,
  listLocalModels,
  deleteLocalModel,
  cancelLocalGeneration,
  getEdgeTokenizerPath,
  setEdgeTokenizerPath,
} from './modelManager';

import {
  getSpeechSpeed,
  setSpeechSpeed,
  getOpenRouterApiKey,
  setOpenRouterApiKey,
  getGeminiApiKey,
  setGeminiApiKey,
  getGroqApiKey,
  setGroqApiKey,
  getHuggingFaceApiKey,
  setHuggingFaceApiKey,
  getCloudflareToken,
  setCloudflareToken,
  getCloudflareAccount,
  setCloudflareAccount,
  getCloudflareModel,
  setCloudflareModel,
  getCustomEndpoint,
  setCustomEndpoint,
  getCustomModel,
  setCustomModel,
  getCustomEndpointKey,
  setCustomEndpointKey,
} from './settings';

import {
  getDueItems,
  getLearningStats,
  nextDueText,
  reviewItem,
  hydrateLearningStateFromSQLite,
  type ReviewRating,
} from './learning';

import {
  buildLearningPlan,
  recordSkillOutcome,
} from './services/adaptiveLearning';

import type { LearningSignal } from './learning';

import {
  runDiagnostics,
  diagnosticsSummary,
  type DiagnosticCheck,
} from './services/diagnosticsEngine';

import {
  listVoicePacks,
  downloadVoicePack,
  deleteDownloadedVoicePack,
  exportVoicePackManifest,
  type VoicePack,
} from './services/voicePackManager';

import {
  DIALECT_PROFILES,
  buildDialectPrompt,
  getDialectProfile,
} from './services/dialectEngine';

import {
  buildDialectLearningPlan,
  getDialectLearningState,
  normalizeDialectId,
  isSupportedDialect,
  recordDialectOutcome,
  dialectMasteryLabel,
  getDialectLearningInsights,
  getDialectDailyGoal,
  hydrateDialectLearningFromSQLite,
} from './services/dialectLearning';

import {
  edgeRuntimeCapabilities,
} from './services/edgeAiRuntime';

import {
  endpointPreset,
  type EndpointProbe,
} from './services/endpointMatrix';

import {
  hydrateEndpointProfilesFromSQLite,
} from './services/endpointProfiles';

import {
  createConversation,
  deleteConversation,
  exportConversations,
  getConversation,
  getCurrentConversationId,
  importConversations,
  listConversations,
  setCurrentConversationId,
  upsertConversation,
  type SavedConversation,
} from './conversationStore';

import {
  privacyReport,
  redactSecrets,
  clearNonSecretAppCache,
  clearDiagnosticData,
} from './services/privacyCenter';

import {
  benchmarkLocalModel,
  type PerformanceResult,
} from './services/performanceLab';

import {
  getDeviceHealth,
  type DeviceHealth,
} from './services/deviceHealth';


const NativeTTS = registerPlugin<any>('NativeTTS');
const LocalAI = registerPlugin<any>('LocalAI');


type Msg = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  provider?: string;
};

type Tab =
  | 'chat'
  | 'search'
  | 'learn'
  | 'dictionary'
  | 'translator'
  | 'settings'
  | 'diagnostics';

type TranslationParts = {
  natural: string;
  literal: string;
  pronunciation: string;
  note: string;
  example: string;
};


function parseTranslation(text: string): TranslationParts {
  const out: TranslationParts = {
    natural: '',
    literal: '',
    pronunciation: '',
    note: '',
    example: '',
  };

  const labels: [keyof TranslationParts, string[]][] = [
    ['natural', ['ترجمه طبیعی', 'natural']],
    [
      'literal',
      [
        'ترجمه تحت‌اللفظی',
        'ترجمه تحت اللفظی',
        'literal',
      ],
    ],
    ['pronunciation', ['تلفظ', 'pronunciation']],
    ['note', ['نکته', 'note']],
    ['example', ['مثال', 'example']],
  ];

  for (const [key, names] of labels) {
    const escapedNames = names.map((x) =>
      x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
    );

    const re = new RegExp(
      `(?:^|\\n)\\s*(?:${escapedNames.join(
        '|',
      )})\\s*[:：-]\\s*([^\\n]*)`,
      'i',
    );

    const match = text.match(re);

    if (match) {
      out[key] = (match[1] || '').trim();
    }
  }

  if (!out.natural) {
    out.natural = text.trim();
  }

  return out;
}


async function speak(
  text: string,
  lang = 'ar-IQ',
) {
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeTTS.speak({
        text,
        lang,
        rate: getSpeechSpeed(),
        pitch: 1,
      });
    } catch (e: any) {
      await addLog(
        'warn',
        `TTS failed: ${e?.message || e}`,
      );
    }

    return;
  }

  try {
    const utterance =
      new SpeechSynthesisUtterance(text);

    utterance.lang = lang;
    utterance.rate = getSpeechSpeed();

    speechSynthesis.cancel();
    speechSynthesis.speak(utterance);
  } catch {
    // Browser TTS is optional.
  }
}


async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Fallback below.
  }

  try {
    const textarea =
      document.createElement('textarea');

    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';

    document.body.appendChild(textarea);

    textarea.focus();
    textarea.select();

    const ok = document.execCommand('copy');

    textarea.remove();

    return ok;
  } catch {
    return false;
  }
}


function localAnswer(text: string) {
  const exact = searchBank(
    text.trim(),
    3,
  )[0];

  if (exact) {
    return [
      'پاسخ از بانک محلی:',
      exact.translation ||
        exact.definition ||
        exact.text,
      '',
      `عبارت مرتبط: ${exact.text}`,
    ].join('\n');
  }

  if (/[\u0600-\u06FF]/.test(text)) {
    return 'مدل محلی یا سرویس آنلاین در دسترس نبود. بانک زبان محلی همچنان فعال است.';
  }

  return 'The local language bank is available, but no AI model is currently ready.';
}


function similarityScore(
  a: string,
  b: string,
) {
  if (!a || !b) {
    return 0;
  }

  const dp = Array.from(
    {
      length: a.length + 1,
    },
    () =>
      Array<number>(
        b.length + 1,
      ).fill(0),
  );

  for (let i = 0; i <= a.length; i++) {
    dp[i]![0] = i;
  }

  for (let j = 0; j <= b.length; j++) {
    dp[0]![j] = j;
  }

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i]![j] =
        a.charAt(i - 1) ===
        b.charAt(j - 1)
          ? dp[i - 1]![j - 1]!
          : 1 +
            Math.min(
              dp[i - 1]![j]!,
              dp[i]![j - 1]!,
              dp[i - 1]![j - 1]!,
            );
    }
  }

  const distance =
    dp[a.length]![b.length]!;

  return Math.max(
    0,
    Math.round(
      (1 -
        distance /
          Math.max(
            a.length,
            b.length,
          )) *
        100,
    ),
  );
}


export default function App() {
  const [tab, setTab] =
    useState<Tab>('chat');

  const [online, setOnline] =
    useState(() => navigator.onLine);

  const [messages, setMessages] =
    useState<Msg[]>([]);

  const [input, setInput] =
    useState('');

  const [busy, setBusy] =
    useState(false);

  const [listening, setListening] =
    useState(false);

  const [toast, setToast] =
    useState('');

  const [conversationId, setConversationId] =
    useState('');

  const [savedConversations, setSavedConversations] =
    useState<SavedConversation[]>([]);

  const conversationReady =
    useRef(false);

  const conversationImportRef =
    useRef<HTMLInputElement>(null);

  const [bank, setBank] =
    useState(getBankItems());

  const [query, setQuery] =
    useState('');

  const [dialect, setDialect] =
    useState<
      'iraqi' |
      'lebanese' |
      'american'
    >('iraqi');

  const [localModel, setLocalModel] =
    useState<any>({
      loaded: false,
    });

  const [localModels, setLocalModels] =
    useState<any[]>([]);

  const [customModels, setCustomModels] =
    useState<string[]>([]);

  const [edgeCaps, setEdgeCaps] =
    useState<any>(null);

  const [logs, setLogs] =
    useState(getLogs());

  const [nativeLogcat, setNativeLogcat] =
    useState('');

  const [translateOut, setTranslateOut] =
    useState('');

  const [targetLang, setTargetLang] =
    useState('ar-IQ');

  const [translationMode, setTranslationMode] =
    useState<'target' | 'persian'>(
      'target',
    );

  const [learnIndex, setLearnIndex] =
    useState(0);

  const [learnScore, setLearnScore] =
    useState(0);

  const [showAnswer, setShowAnswer] =
    useState(false);

  const [learnFilter, setLearnFilter] =
    useState('all');

  const [learnDialect, setLearnDialect] =
    useState<
      | 'iraqi'
      | 'lebanese'
      | 'gulf'
      | 'saudi'
      | 'egyptian'
      | 'msa'
      | 'american'
    >('iraqi');

  const [pronunciationFeedback, setPronunciationFeedback] =
    useState('');

  const [pronouncing, setPronouncing] =
    useState(false);

  const [speechInfo, setSpeechInfo] =
    useState<any>(null);

  const [diagChecks, setDiagChecks] =
    useState<DiagnosticCheck[]>([]);

  const [diagRunning, setDiagRunning] =
    useState(false);

  const [voicePacks, setVoicePacks] =
    useState<VoicePack[]>(() =>
      listVoicePacks(),
    );

  const [voiceBusy, setVoiceBusy] =
    useState('');

  const [discoveredModels, setDiscoveredModels] =
    useState<DiscoveredModel[]>([]);

  const [modelDiscoveryBusy, setModelDiscoveryBusy] =
    useState(false);

  const [dialectTarget, setDialectTarget] =
    useState('iraqi');

  const [privacy, setPrivacy] =
    useState(() => privacyReport());

  const [deviceHealth, setDeviceHealth] =
    useState<DeviceHealth | null>(null);

  const [benchmark, setBenchmark] =
    useState<PerformanceResult | null>(
      null,
    );

  const [benchmarkBusy, setBenchmarkBusy] =
    useState(false);

  const [orKey, setOrKey] =
    useState(getOpenRouterApiKey());

  const [gemKey, setGemKey] =
    useState(getGeminiApiKey());

  const [groqKey, setGroqKey] =
    useState(getGroqApiKey());

  const [hfKey, setHfKey] =
    useState(getHuggingFaceApiKey());

  const [cfToken, setCfToken] =
    useState(getCloudflareToken());

  const [cfAccount, setCfAccount] =
    useState(getCloudflareAccount());

  const [cfModel, setCfModel] =
    useState(getCloudflareModel());

  const [customEndpoint, setCustomEndpointState] =
    useState(getCustomEndpoint());

  const [customModel, setCustomModelState] =
    useState(getCustomModel());

  const [customEndpointKey, setCustomEndpointKeyState] =
    useState(getCustomEndpointKey());

  const [speechSpeed, setSpeed] =
    useState(getSpeechSpeed());

  const [endpointProbe, setEndpointProbe] =
    useState<EndpointProbe | null>(null);

  const [endpointProbeBusy, setEndpointProbeBusy] =
    useState(false);

  const [importDialect, setImportDialect] =
    useState<
      | 'iraqi'
      | 'lebanese'
      | 'gulf'
      | 'saudi'
      | 'egyptian'
      | 'msa'
      | 'american'
    >('iraqi');

  const fileRef =
    useRef<HTMLInputElement>(null);

  const endRef =
    useRef<HTMLDivElement>(null);

  const cancelRequested =
    useRef(false);


  useEffect(() => {
    void initLanguageBank().then(
      async () => {
        await hydrateLearningStateFromSQLite();
        await hydrateDialectLearningFromSQLite();
        await hydrateEndpointProfilesFromSQLite();

        setBank(getBankItems());
      },
    );

    void (async () => {
      const models =
        await listLocalModels();

      setLocalModels(models);

      const status =
        await localModelStatus();

      const savedPath =
        localStorage.getItem(
          'yaali_local_model',
        ) || '';

      if (savedPath) {
        const result =
          await loadLocalModel(
            savedPath,
          );

        setLocalModel(result);

        setLocalModels(
          await listLocalModels(),
        );

        await addLog(
          result.engineReady
            ? 'info'
            : 'warn',
          `startup local model ${
            result.engineReady
              ? 'loaded'
              : 'failed'
          }: ${
            result.error ||
            result.name ||
            savedPath
          }`,
        );

        setLogs(getLogs());
      } else {
        setLocalModel(status);
      }
    })();

    void speechAvailability().then(
      setSpeechInfo,
    );

    void edgeRuntimeCapabilities().then(
      setEdgeCaps,
    );

    setSavedConversations(
      listConversations(),
    );

    const currentId =
      getCurrentConversationId();

    const currentConversation =
      currentId
        ? getConversation(currentId)
        : null;

    if (currentConversation) {
      setConversationId(
        currentConversation.id,
      );

      setMessages(
        currentConversation.messages,
      );

      setDialect(
        currentConversation.dialect,
      );

      setTargetLang(
        currentConversation.dialect ===
          'american'
          ? 'en-US'
          : currentConversation.dialect ===
              'lebanese'
            ? 'ar-LB'
            : 'ar-IQ',
      );
    } else {
      const created =
        createConversation('iraqi');

      setConversationId(
        created.id,
      );

      setSavedConversations(
        listConversations(),
      );
    }

    conversationReady.current = true;

    if (getCustomEndpoint()) {
      void discoverCustomModels().then(
        (models) => {
          setCustomModels(models);

          if (
            models.length &&
            !getCustomModel()
          ) {
            const first =
              models[0];

            if (first) {
              setCustomModelState(
                first,
              );

              setCustomModel(first);
            }
          }
        },
      );
    }
  }, []);


  useEffect(() => {
    const onResize = () => {
      document.documentElement.style.setProperty(
        '--vh',
        `${window.innerHeight * 0.01}px`,
      );
    };

    onResize();

    window.addEventListener(
      'resize',
      onResize,
    );

    return () => {
      window.removeEventListener(
        'resize',
        onResize,
      );
    };
  }, []);


  useEffect(() => {
    const on = () =>
      setOnline(true);

    const off = () =>
      setOnline(false);

    window.addEventListener(
      'online',
      on,
    );

    window.addEventListener(
      'offline',
      off,
    );

    return () => {
      window.removeEventListener(
        'online',
        on,
      );

      window.removeEventListener(
        'offline',
        off,
      );
    };
  }, []);


  useEffect(() => {
    endRef.current?.scrollIntoView({
      behavior: 'smooth',
    });
  }, [messages, busy]);


  useEffect(() => {
    void getDeviceHealth().then(
      setDeviceHealth,
    );
  }, []);


  useEffect(() => {
    if (
      !conversationReady.current ||
      !conversationId
    ) {
      return;
    }

    const timer =
      window.setTimeout(() => {
        const existing =
          getConversation(
            conversationId,
          );

        upsertConversation({
          id: conversationId,
          title:
            messages
              .find(
                (m) =>
                  m.role ===
                  'user',
              )
              ?.text?.slice(
                0,
                48,
              ) ||
            'مکالمه جدید',

          createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

          updatedAt:
            new Date().toISOString(),

          dialect,
          messages,
        });

        setSavedConversations(
          listConversations(),
        );
      }, 120);

    return () =>
      window.clearTimeout(timer);
  }, [
    messages,
    conversationId,
    dialect,
  ]);


  useEffect(() => {
    if (
      !Capacitor.isNativePlatform()
    ) {
      return;
    }

    const onBack = () => {
      if (tab !== 'chat') {
        setTab('chat');
        return;
      }

      setToast(
        'برای خروج، دوباره دکمه بازگشت را بزنید',
      );
    };

    window.addEventListener(
      'yaaliBack',
      onBack,
    );

    return () => {
      window.removeEventListener(
        'yaaliBack',
        onBack,
      );
    };
  }, [tab]);


  const supportedBank =
    useMemo(
      () =>
        bank.filter((item) =>
          isSupportedDialect(
            item.dialect ||
              item.source_language,
          ),
        ),
      [bank],
    );


  const results =
    useMemo(
      () =>
        searchBank(
          query,
          200,
        ).filter(
          (item) =>
            learnFilter ===
              'all' ||
            String(
              item.dialect || '',
            ).includes(
              learnFilter,
            ),
        ),
      [
        query,
        bank,
        learnFilter,
      ],
    );


  const due =
    useMemo(
      () =>
        getDueItems(
          supportedBank,
        ),
      [supportedBank],
    );


  const learningPlan =
    useMemo(
      () =>
        buildLearningPlan(
          supportedBank,
          12,
        ),
      [supportedBank],
    );


  const dialectPlan =
    useMemo(
      () =>
        buildDialectLearningPlan(
          supportedBank,
          learnDialect,
          24,
        ),
      [
        supportedBank,
        learnDialect,
      ],
    );


  const dialectState =
    getDialectLearningState(
      learnDialect,
    );

  const dialectInsights =
    getDialectLearningInsights(
      learnDialect,
    );


  const learningPool =
    useMemo(() => {
      const pool =
        due.length
          ? due
          : supportedBank;

      const dialectPool =
        pool.filter(
          (item) =>
            normalizeDialectId(
              item.dialect ||
                item.source_language,
            ) ===
            learnDialect,
        );

      return dialectPool.length
        ? dialectPool
        : dialectPlan.map(
            (item) =>
              item.item,
          );
    }, [
      due,
      supportedBank,
      learnDialect,
      dialectPlan,
    ]);


  const current =
    learningPool.length
      ? learningPool[
          learnIndex %
            learningPool.length
        ]
      : supportedBank.length
        ? supportedBank[
            learnIndex %
              supportedBank.length
          ]
        : undefined;


  const stats =
    getLearningStats(
      supportedBank,
    );


  const providers =
    configuredProviders();

  const localEndpointConfigured =
    providers.includes(
      'custom',
    );


  const newConversation = () => {
    if (busy) {
      return;
    }

    const conversation =
      createConversation(
        dialect,
      );

    setConversationId(
      conversation.id,
    );

    setCurrentConversationId(
      conversation.id,
    );

    setMessages([]);

    setInput('');

    setTranslateOut('');

    setSavedConversations(
      listConversations(),
    );

    setToast(
      'مکالمه جدید ساخته شد ✓',
    );
  };


  const loadConversation = (
    id: string,
  ) => {
    if (busy) {
      return;
    }

    const conversation =
      getConversation(id);

    if (!conversation) {
      return;
    }

    setConversationId(
      conversation.id,
    );

    setCurrentConversationId(
      conversation.id,
    );

    setMessages(
      conversation.messages,
    );

    setDialect(
      conversation.dialect,
    );

    setTargetLang(
      conversation.dialect ===
        'american'
        ? 'en-US'
        : conversation.dialect ===
            'lebanese'
          ? 'ar-LB'
          : 'ar-IQ',
    );

    setSavedConversations(
      listConversations(),
    );

    setToast(
      'مکالمه بازیابی شد ✓',
    );
  };


  const removeConversation = (
    id: string,
  ) => {
    if (busy) {
      return;
    }

    deleteConversation(id);

    if (
      id === conversationId
    ) {
      const next =
        listConversations()[0];

      if (next) {
        loadConversation(
          next.id,
        );
      } else {
        newConversation();
      }
    } else {
      setSavedConversations(
        listConversations(),
      );
    }
  };


  const downloadJson = (
    name: string,
    text: string,
  ) => {
    const blob =
      new Blob(
        [text],
        {
          type:
            'application/json;charset=utf-8',
        },
      );

    const url =
      URL.createObjectURL(
        blob,
      );

    const anchor =
      document.createElement(
        'a',
      );

    anchor.href = url;
    anchor.download = name;

    document.body.appendChild(
      anchor,
    );

    anchor.click();

    anchor.remove();

    window.setTimeout(
      () =>
        URL.revokeObjectURL(
          url,
        ),
      1000,
    );
  };


  const send = async () => {
    const text =
      input.trim();

    if (
      !text ||
      busy
    ) {
      return;
    }

    cancelRequested.current =
      false;

    setInput('');

    const userMessage: Msg = {
      id:
        crypto.randomUUID(),
      role: 'user',
      text,
    };

    const history = [
      ...messages,
      userMessage,
    ];

    setMessages(history);

    setBusy(true);

    const activeDialect =
      dialectTarget ||
      dialect;

    const profile =
      getDialectProfile(
        activeDialect,
      );

    const dialectName =
      profile.labelFa;

    const system =
      `You are Ya Ali, a warm intelligent language partner for a Persian-speaking learner. Teach naturally in ${dialectName}. ${buildDialectPrompt(activeDialect)} Use colloquial target language for dialects, not Modern Standard Arabic unless the user explicitly asks for MSA. Explain difficult points briefly in Persian, correct meaningful mistakes gently, and keep the conversation natural. Prefer useful everyday expressions.`;

    try {
      let reply = '';
      let provider = '';

      if (
        localModel.engineReady
      ) {
        try {
          reply =
            await localChat([
              {
                role: 'system',
                content: system,
              },
              ...history
                .slice(-10)
                .map(
                  (message) => ({
                    role:
                      message.role,
                    content:
                      message.text,
                  }),
                ),
            ]);

          provider =
            'Local AI · ' +
            (localModel.name ||
              'GGUF');
        } catch (e: any) {
          await addLog(
            'warn',
            `local AI failed; trying online: ${
              e?.message || e
            }`,
          );
        }
      }

      if (
        cancelRequested.current
      ) {
        setToast(
          'تولید پاسخ متوقف شد',
        );
        return;
      }

      if (
        !reply &&
        (online &&
          providers.length ||
          localEndpointConfigured)
      ) {
        try {
          const result =
            await chat([
              {
                role: 'system',
                content: system,
              },
              ...history
                .slice(-12)
                .map(
                  (message) => ({
                    role:
                      message.role,
                    content:
                      message.text,
                  }),
                ),
            ]);

          reply =
            result.text;

          provider =
            providerLabel(
              result.provider,
            );
        } catch (e: any) {
          await addLog(
            'warn',
            `online AI failed; using local search: ${
              e?.message || e
            }`,
          );
        }
      }

      if (!reply) {
        reply =
          localAnswer(text);

        provider =
          'Local Search';
      }

      setMessages(
        (previous) => [
          ...previous,
          {
            id:
              crypto.randomUUID(),
            role: 'assistant',
            text: reply,
            provider,
          },
        ],
      );

      await addLog(
        'info',
        `chat completed provider=${provider}`,
      );

      setLogs(
        getLogs(),
      );
    } catch (e: any) {
      await addLog(
        'error',
        `chat failed: ${
          e?.message || e
        }`,
      );

      setLogs(
        getLogs(),
      );

      setMessages(
        (previous) => [
          ...previous,
          {
            id:
              crypto.randomUUID(),
            role: 'assistant',
            text:
              localAnswer(
                text,
              ),
            provider:
              'Local Search',
          },
        ],
      );
    } finally {
      setBusy(false);

      setLocalModel(
        await localModelStatus(),
      );
    }
  };


  const translate = async () => {
    const text =
      input.trim();

    if (!text) {
      return;
    }

    setBusy(true);

    try {
      const targetName =
        targetLang === 'ar-IQ'
          ? 'Iraqi Arabic'
          : targetLang === 'ar-LB'
            ? 'Lebanese Arabic'
            : 'American English';

      if (
        localModel.engineReady ||
        (online &&
          providers.length) ||
        localEndpointConfigured
      ) {
        const instruction =
          translationMode ===
          'target'
            ? `Translate into ${targetName}`
            : 'Translate into natural Persian';

        const system =
          `You are a professional Persian-first language tutor. ${instruction}. For Iraqi/Lebanese Arabic use genuinely colloquial forms, not Modern Standard Arabic. Return exactly these labeled lines: ترجمه طبیعی, ترجمه تحت‌اللفظی, تلفظ, نکته, مثال. Keep each line short.`;

        const resultText =
          localModel.engineReady
            ? await localChat([
                {
                  role: 'system',
                  content:
                    system,
                },
                {
                  role: 'user',
                  content: text,
                },
              ])
            : (
                await chat([
                  {
                    role: 'system',
                    content:
                      system,
                  },
                  {
                    role: 'user',
                    content: text,
                  },
                ])
              ).text;

        setTranslateOut(
          resultText,
        );
      } else {
        const item =
          searchBank(
            text,
            5,
          )[0];

        setTranslateOut(
          item
            ? `ترجمه طبیعی: ${
                item.translation ||
                item.definition ||
                '—'
              }\nتلفظ: ${
                item.pronunciation ||
                item.transliteration ||
                '—'
              }\nمثال: ${
                item.example_text ||
                '—'
              }\nنکته: ${
                item.topic ||
                '—'
              }`
            : 'برای این متن ترجمه محلی پیدا نشد.',
        );
      }
    } catch (e: any) {
      await addLog(
        'warn',
        `translation failed: ${
          e?.message || e
        }`,
      );

      const item =
        searchBank(
          text,
          5,
        )[0];

      setTranslateOut(
        item
          ? `ترجمه طبیعی: ${
              item.translation ||
              item.definition ||
              '—'
            }\nتلفظ: ${
              item.pronunciation ||
              item.transliteration ||
              '—'
            }\nمثال: ${
              item.example_text ||
              '—'
            }`
          : 'ترجمه ناموفق بود؛ اتصال AI یا بانک زبان را بررسی کنید.',
      );
    } finally {
      setBusy(false);
    }
  };


  const rateLearn = async (
    rating: ReviewRating,
  ) => {
    if (!current) {
      return;
    }

    const focus =
      (
        dialectPlan.find(
          (item) =>
            item.item.id ===
            current.id,
        )?.focus ||
        learningPlan.find(
          (item) =>
            item.item.id ===
            current.id,
        )?.focus ||
        'vocabulary'
      ) as LearningSignal;

    reviewItem(
      current.id,
      rating,
      {
        signal: focus,
      },
    );

    recordSkillOutcome(
      focus,
      rating !== 'again',
    );

    recordDialectOutcome(
      learnDialect,
      rating,
      focus ===
        'pronunciation'
        ? 'pronunciation'
        : focus ===
            'listening'
          ? 'listening'
          : focus ===
              'grammar'
            ? 'grammar'
            : focus ===
                'conversation'
              ? 'conversation'
              : focus ===
                  'vocabulary'
                ? 'vocabulary'
                : 'recognition',
    );

    if (
      rating !== 'again'
    ) {
      setLearnScore(
        (score) =>
          score + 1,
      );
    }

    setShowAnswer(false);

    setLearnIndex(
      (index) =>
        index + 1,
    );

    await saveBankItem({
      ...current,
      learned:
        rating === 'again'
          ? 0
          : 1,
    });
  };


  const pronunciationCoach =
    async () => {
      if (
        !current ||
        pronouncing
      ) {
        return;
      }

      setPronouncing(true);

      setPronunciationFeedback(
        'در حال گوش دادن…',
      );

      try {
        const expected =
          String(
            current.text ||
              '',
          ).trim();

        const lang =
          getLangCode(
            current.dialect,
            current.source_language ===
              'en'
              ? 'english'
              : 'arabic',
          );

        const spoken =
          String(
            (await listenSpeech(
              lang,
            )) || '',
          );

        const a =
          spoken
            .toLocaleLowerCase()
            .replace(
              /[^\p{L}\p{N}]+/gu,
              '',
            )
            .trim();

        const b =
          expected
            .toLocaleLowerCase()
            .replace(
              /[^\p{L}\p{N}]+/gu,
              '',
            )
            .trim();

        if (!a) {
          setPronunciationFeedback(
            'صدایی تشخیص داده نشد.',
          );
          return;
        }

        const score =
          similarityScore(
            a,
            b,
          );

        recordDialectOutcome(
          learnDialect,
          score >= 85
            ? 'easy'
            : score >= 65
              ? 'good'
              : 'again',
          'pronunciation',
        );

        setPronunciationFeedback(
          `شباهت متنی: ${score}٪ · ${
            score >= 85
              ? 'عالی — یک بار دیگر با ریتم طبیعی تکرار کن.'
              : score >= 65
                ? 'خوب — یک بار دیگر تمرین کن.'
                : 'نیاز به تمرین بیشتر دارد.'
          }`,
        );
      } catch (e: any) {
        setPronunciationFeedback(
          e?.message ||
            'تمرین تلفظ ناموفق بود.',
        );
      } finally {
        setPronouncing(false);
      }
    };


  const startSpeech =
    async () => {
      if (listening) {
        await stopSpeech();
        setListening(false);
        return;
      }

      try {
        setListening(true);

        setToast(
          '🎙️ در حال گوش دادن…',
        );

        const text =
          String(
            (await listenSpeech(
              'fa-IR',
            )) || '',
          );

        if (text) {
          setInput(
            (value) =>
              value
                ? `${value} ${text}`
                : text,
          );
        }

        setToast(
          text
            ? 'متن دریافت شد ✓'
            : 'صدایی تشخیص داده نشد',
        );
      } catch (e: any) {
        await addLog(
          'warn',
          `speech failed: ${
            e?.message || e
          }`,
        );

        setToast(
          `تشخیص گفتار: ${
            e?.message ||
            'ناموفق'
          }`,
        );
      } finally {
        setListening(false);
      }
    };


  const nav = [
    ['chat', 'مکالمه', Bot],
    ['search', 'جستجو', Search],
    ['learn', 'یادگیری', Brain],
    [
      'dictionary',
      'واژه‌نامه',
      BookOpen,
    ],
    [
      'translator',
      'مترجم',
      Languages,
    ],
    [
      'settings',
      'تنظیمات',
      SettingsIcon,
    ],
    [
      'diagnostics',
      'عیب‌یابی',
      SettingsIcon,
    ],
  ] as const;


  const tparts =
    parseTranslation(
      translateOut,
    );


  const filterLabel = (
    id: string,
  ) =>
    id === 'عراقی'
      ? 'عراقی'
      : id === 'لبنانی'
        ? 'لبنانی'
        : id === 'آمریکایی'
          ? 'آمریکایی'
          : 'همه';


  return (
    <div
      dir="rtl"
      className={`app tab-${tab}`}
    >
      <header className="topbar">
        <div>
          <div className="brand">
            Ya Ali
          </div>

          <div className="subtitle">
            یا امیرالمؤمنین علی
            علیه السلام · دستیار
            هوشمند زبان
          </div>
        </div>

        <div
          className={
            online
              ? 'status online'
              : 'status'
          }
        >
          {online ? (
            <Wifi size={15} />
          ) : (
            <WifiOff size={15} />
          )}

          {online
            ? 'آنلاین'
            : 'آفلاین'}
        </div>
      </header>


      <main className="main">
        {tab === 'chat' && (
          <section className="panel chat-panel">
            <div className="hero">
              <Bot size={28} />

              <div>
                <h1>
                  مکالمه هوشمند
                </h1>

                <p>
                  اولویت با
                  On-device AI؛ سپس
                  سرویس آنلاین و در
                  پایان بانک زبان
                </p>
              </div>
            </div>


            <div className="conversationToolbar">
              <button
                onClick={
                  newConversation
                }
              >
                <RotateCcw
                  size={15}
                />
                مکالمه جدید
              </button>

              <select
                value={
                  conversationId
                }
                onChange={(event) =>
                  loadConversation(
                    event.target
                      .value,
                  )
                }
              >
                <option value="">
                  انتخاب مکالمه
                  ذخیره‌شده
                </option>

                {savedConversations.map(
                  (conversation) => (
                    <option
                      key={
                        conversation.id
                      }
                      value={
                        conversation.id
                      }
                    >
                      {
                        conversation.title
                      }{' '}
                      ·{' '}
                      {new Date(
                        conversation.updatedAt,
                      ).toLocaleDateString(
                        'fa-IR',
                      )}
                    </option>
                  ),
                )}
              </select>

              <button
                onClick={() =>
                  downloadJson(
                    'ya-ali-conversations.json',
                    exportConversations(),
                  )
                }
              >
                <Download
                  size={15}
                />
                خروجی
              </button>

              <button
                onClick={() =>
                  conversationImportRef.current?.click()
                }
              >
                <Upload
                  size={15}
                />
                ورود
              </button>

              {conversationId && (
                <button
                  className="dangerBtn"
                  onClick={() =>
                    removeConversation(
                      conversationId,
                    )
                  }
                >
                  <Trash2
                    size={15}
                  />
                  حذف
                </button>
              )}

              <input
                ref={
                  conversationImportRef
                }
                type="file"
                accept=".json,application/json"
                hidden
                onChange={async (
                  event,
                ) => {
                  const file =
                    event.target
                      .files?.[0];

                  event.currentTarget.value =
                    '';

                  if (!file) {
                    return;
                  }

                  try {
                    const count =
                      importConversations(
                        JSON.parse(
                          await file.text(),
                        ),
                      );

                    setSavedConversations(
                      listConversations(),
                    );

                    const first =
                      listConversations()[0];

                    if (first) {
                      loadConversation(
                        first.id,
                      );
                    }

                    setToast(
                      count
                        ? `${count} مکالمه وارد شد ✓`
                        : 'مکالمه‌ای در فایل پیدا نشد',
                    );
                  } catch {
                    setToast(
                      'فایل مکالمه معتبر نیست',
                    );
                  }
                }}
              />
            </div>


            <div className="miniStats">
              <span>
                <BarChart3
                  size={15}
                />
                {stats.reviewed}{' '}
                مرور
              </span>

              <span>
                🔥 {stats.streak}{' '}
                روز پیاپی
              </span>

              <span>
                <BookOpen
                  size={15}
                />
                {supportedBank.length.toLocaleString(
                  'fa-IR',
                )}{' '}
                مورد
              </span>

              <span>
                {localModel.engineReady
                  ? '🟢 Local AI آماده'
                  : '⚪ Local AI خاموش'}
              </span>
            </div>


            <div className="selectors">
              <label>
                زبان هدف

                <select
                  value={dialect}
                  onChange={(event) => {
                    const value =
                      event.target
                        .value as
                        | 'iraqi'
                        | 'lebanese'
                        | 'american';

                    setDialect(
                      value,
                    );

                    setTargetLang(
                      value ===
                        'american'
                        ? 'en-US'
                        : value ===
                            'lebanese'
                          ? 'ar-LB'
                          : 'ar-IQ',
                    );
                  }}
                >
                  <option value="iraqi">
                    عربی عراقی
                  </option>

                  <option value="lebanese">
                    عربی لبنانی
                  </option>

                  <option value="american">
                    انگلیسی آمریکایی
                  </option>
                </select>
              </label>
            </div>


            <div className="messages">
              {messages.length ===
                0 && (
                <div className="empty">
                  <Bot size={44} />

                  <h2>
                    سلام! 👋
                  </h2>

                  <p>
                    یک سؤال بپرس،
                    ترجمه بخواه یا با
                    یکی از سه زبان هدف
                    تمرین کن.
                  </p>

                  <p className="muted">
                    {localModel.engineReady
                      ? `مدل محلی فعال است: ${
                          localModel.name ||
                          'GGUF'
                        }`
                      : 'برای مکالمه کاملاً آفلاین، GGUF/llama.cpp یا Runtime محلی ONNX/PTE لازم است؛ Endpoint محلی نیز بدون اینترنت عمومی کار می‌کند.'}
                  </p>
                </div>
              )}


              {messages.map(
                (message) => (
                  <div
                    key={
                      message.id
                    }
                    className={
                      'bubble ' +
                      message.role
                    }
                  >
                    <div className="bubbleText">
                      {
                        message.text
                      }
                    </div>

                    {message.provider && (
                      <small>
                        {
                          message.provider
                        }
                      </small>
                    )}

                    {message.role ===
                      'assistant' && (
                      <div className="bubbleActions">
                        <button
                          className="iconBtn"
                          onClick={() =>
                            void speak(
                              message.text,
                              targetLang.startsWith(
                                'ar',
                              )
                                ? targetLang
                                : 'en-US',
                            )
                          }
                          aria-label="پخش"
                        >
                          <Volume2
                            size={17}
                          />
                        </button>

                        <button
                          className="iconBtn"
                          onClick={async () =>
                            setToast(
                              (await copyText(
                                message.text,
                              ))
                                ? 'کپی شد ✓'
                                : 'کپی ناموفق بود',
                            )
                          }
                          aria-label="کپی"
                        >
                          <Copy
                            size={15}
                          />
                          کپی
                        </button>
                      </div>
                    )}
                  </div>
                ),
              )}


              {busy && (
                <div className="typing">
                  {localModel.engineReady
                    ? '🤖 مدل محلی در حال تولید پاسخ…'
                    : 'در حال دریافت پاسخ هوشمند…'}
                </div>
              )}

              <div ref={endRef} />
            </div>


            <div className="composer">
              <textarea
                value={input}
                onChange={(event) =>
                  setInput(
                    event.target.value,
                  )
                }
                onKeyDown={(event) => {
                  if (
                    event.key ===
                      'Enter' &&
                    !event.shiftKey
                  ) {
                    event.preventDefault();
                    void send();
                  }
                }}
                placeholder="پیام خود را بنویسید…"
                rows={2}
              />

              <button
                className={
                  listening
                    ? 'iconBtn micBtn listening'
                    : 'iconBtn micBtn'
                }
                aria-label="ضبط صدا"
                onClick={() =>
                  void startSpeech()
                }
              >
                {listening ? (
                  <Square size={19} />
                ) : (
                  <Mic size={20} />
                )}
              </button>

              {busy &&
              localModel.engineReady ? (
                <button
                  className="sendBtn stopBtn"
                  onClick={async () => {
                    cancelRequested.current =
                      true;

                    await cancelLocalGeneration();

                    setBusy(false);

                    setLocalModel(
                      await localModelStatus(),
                    );

                    setToast(
                      'تولید پاسخ متوقف شد',
                    );
                  }}
                >
                  <Square
                    size={18}
                  />
                </button>
              ) : (
                <button
                  className="sendBtn"
                  onClick={() =>
                    void send()
                  }
                  disabled={
                    busy ||
                    !input.trim()
                  }
                >
                  <Send size={20} />
                </button>
              )}
            </div>
          </section>
        )}


        {tab === 'search' && (
          <section className="panel">
            <h1>
              🔎 جستجوی بانک زبان
            </h1>

            <p className="muted">
              جستجوی فارسی، عربی،
              انگلیسی، تلفظ، ترجمه،
              لهجه و موضوع.
            </p>

            <div className="chips">
              {DIALECT_FILTERS.map(
                (filter) => (
                  <button
                    key={filter.id}
                    className={
                      learnFilter ===
                      (filter.id ===
                      'all'
                        ? 'all'
                        : filter.id)
                        ? 'chip active'
                        : 'chip'
                    }
                    onClick={() =>
                      setLearnFilter(
                        filter.id ===
                          'all'
                          ? 'all'
                          : filter.id,
                      )
                    }
                  >
                    {filter.label}
                  </button>
                ),
              )}
            </div>

            <input
              className="search"
              value={query}
              onChange={(event) =>
                setQuery(
                  event.target.value,
                )
              }
              placeholder="مثلاً: فرودگاه، سلام، airport…"
            />

            <div className="count">
              {results.length.toLocaleString(
                'fa-IR',
              )}{' '}
              نتیجه از{' '}
              {supportedBank.length.toLocaleString(
                'fa-IR',
              )}{' '}
              مورد
            </div>

            <div className="cards">
              {results.map(
                (item) => (
                  <div
                    className="wordCard"
                    key={item.id}
                  >
                    <div className="word">
                      {item.text}
                    </div>

                    <div>
                      {item.translation ||
                        item.definition}
                    </div>

                    <div className="phon">
                      {item.pronunciation ||
                        item.transliteration ||
                        '—'}
                    </div>

                    <small>
                      {item.dialect ||
                        '—'}{' '}
                      ·{' '}
                      {item.topic ||
                        'عمومی'}{' '}
                      ·{' '}
                      {item.level ||
                        '—'}
                    </small>

                    <div className="cardActions">
                      <button
                        onClick={() =>
                          void speak(
                            item.text ||
                              '',
                            getLangCode(
                              item.dialect ||
                                '',
                              item.source_language ===
                                'en'
                                ? 'english'
                                : 'arabic',
                            ),
                          )
                        }
                      >
                        <Volume2
                          size={16}
                        />
                        تلفظ
                      </button>

                      <button
                        onClick={() =>
                          void saveBankItem({
                            ...item,
                            id: `fav_${Date.now()}`,
                            favorite: 1,
                          })
                        }
                      >
                        <Star size={16} />
                        ذخیره
                      </button>
                    </div>
                  </div>
                ),
              )}
            </div>
          </section>
        )}


        {tab === 'learn' && (
          <section className="panel learn">
            <h1>
              🧠 یادگیری و مرور هوشمند
            </h1>

            <p className="muted">
              FSRS-6 + Adaptive
              Learning: زمان مرور و
              اولویت تمرین از عملکرد
              واقعی شما یاد می‌گیرد.
            </p>

            <div className="providerGrid">
              <span>
                FSRS-6 · retention 90%
              </span>

              <span>
                پایداری میانگین:{' '}
                {stats.averageStability ||
                  0}{' '}
                روز
              </span>

              <span>
                دشواری میانگین:{' '}
                {stats.averageDifficulty ||
                  0}
                /10
              </span>

              <span>
                خطا/لپس:{' '}
                {stats.lapses || 0}
              </span>
            </div>

            <div className="notice">
              اولویت تمرین از
              عقب‌افتادگی، دشواری،
              تعداد خطاها و مهارت
              ضعیف‌تر ساخته می‌شود؛
              این لایه فاصله‌های
              FSRS را دستکاری نمی‌کند.
            </div>

            <div className="miniStats">
              <span>
                کل:{' '}
                {stats.total.toLocaleString(
                  'fa-IR',
                )}
              </span>

              <span>
                موعد امروز:{' '}
                {stats.due.toLocaleString(
                  'fa-IR',
                )}
              </span>

              <span>
                یادگرفته:{' '}
                {stats.learned.toLocaleString(
                  'fa-IR',
                )}
              </span>

              <span>
                🔥 {stats.streak}{' '}
                روز پیاپی
              </span>
            </div>

            <div className="chips">
              {DIALECT_PROFILES.map(
                (profile) => (
                  <button
                    key={profile.id}
                    className={
                      learnDialect ===
                      profile.id
                        ? 'chip active'
                        : 'chip'
                    }
                    onClick={() => {
                      setLearnDialect(
                        profile.id,
                      );

                      setLearnIndex(
                        0,
                      );

                      setShowAnswer(
                        false,
                      );
                    }}
                  >
                    {profile.labelFa}
                  </button>
                ),
              )}
            </div>

            <div className="providerGrid">
              <span>
                🎯{' '}
                {
                  DIALECT_PROFILES.find(
                    (profile) =>
                      profile.id ===
                      learnDialect,
                  )?.labelFa
                }
              </span>

              <span>
                تسلط:{' '}
                {Math.round(
                  dialectState.mastery,
                )}
                ٪ ·{' '}
                {dialectMasteryLabel(
                  dialectState.mastery,
                )}
              </span>

              <span>
                اعتماد:{' '}
                {Math.round(
                  dialectState.confidence,
                )}
                ٪
              </span>

              <span>
                تمرین:{' '}
                {dialectState.exposure.toLocaleString(
                  'fa-IR',
                )}{' '}
                · موفق:{' '}
                {dialectState.successes.toLocaleString(
                  'fa-IR',
                )}
              </span>

              <span>
                نگهداشت:{' '}
                {Math.round(
                  dialectInsights.retention *
                    100,
                )}
                ٪ · سطح:{' '}
                {
                  dialectInsights.level
                }
              </span>

              <span>
                هدف روزانه:{' '}
                {getDialectDailyGoal(
                  learnDialect,
                )}{' '}
                مورد
              </span>
            </div>

            <div className="notice">
              مسیر یادگیری این لهجه
              جداگانه امتیازدهی می‌شود؛
              تمرین‌های شنیدار، تلفظ،
              مکالمه، واژگان، دستور و
              تشخیص لهجه با عملکرد شما
              وزن می‌گیرند و از اختلاط
              گونه‌ها جلوگیری می‌شود.
            </div>

            {current ? (
              <>
                <div className="learnCard">
                  <div className="label">
                    {current.dialect} ·{' '}
                    {current.level} ·{' '}
                    {current.topic}
                  </div>

                  <div className="big">
                    {current.text}
                  </div>

                  <div className="phon">
                    {current.transliteration ||
                      current.pronunciation ||
                      'برای شنیدن از دکمه تلفظ استفاده کنید'}
                  </div>

                  <button
                    onClick={() =>
                      void speak(
                        current.text ||
                          '',
                        getLangCode(
                          current.dialect ||
                            '',
                          current.source_language ===
                            'en'
                            ? 'english'
                            : 'arabic',
                        ),
                      )
                    }
                    className="wide"
                  >
                    <Volume2 />
                    شنیدن تلفظ
                  </button>

                  <button
                    onClick={() =>
                      void pronunciationCoach()
                    }
                    className="wide coachBtn"
                    disabled={
                      pronouncing
                    }
                  >
                    <Mic />
                    {pronouncing
                      ? 'در حال گوش دادن…'
                      : 'تمرین تلفظ با میکروفن'}
                  </button>

                  {pronunciationFeedback && (
                    <div className="coachFeedback">
                      {
                        pronunciationFeedback
                      }
                    </div>
                  )}

                  {!showAnswer ? (
                    <button
                      className="primary wide"
                      onClick={() =>
                        setShowAnswer(
                          true,
                        )
                      }
                    >
                      نمایش معنی
                    </button>
                  ) : (
                    <div className="answerPanel">
                      <div className="translation">
                        {current.translation ||
                          current.definition}
                      </div>

                      <p>
                        {current.example_text ||
                          ''}
                      </p>

                      <p className="muted">
                        {current.example_translation ||
                          ''}
                      </p>

                      <small>
                        <Clock3
                          size={13}
                        />
                        {nextDueText(
                          current.id,
                        )}
                      </small>
                    </div>
                  )}
                </div>

                <div className="learnActions">
                  <button
                    onClick={() =>
                      void rateLearn(
                        'again',
                      )
                    }
                  >
                    <RotateCcw
                      size={16}
                    />
                    دوباره
                  </button>

                  <button
                    onClick={() =>
                      void rateLearn(
                        'hard',
                      )
                    }
                  >
                    سخت
                  </button>

                  <button
                    onClick={() =>
                      void rateLearn(
                        'good',
                      )
                    }
                  >
                    <Check size={16} />
                    خوب
                  </button>

                  <button
                    onClick={() =>
                      void rateLearn(
                        'easy',
                      )
                    }
                  >
                    آسان
                  </button>
                </div>

                <div className="score">
                  موفقیت این نشست:{' '}
                  {learnScore.toLocaleString(
                    'fa-IR',
                  )}
                </div>
              </>
            ) : (
              <div className="empty">
                <Brain size={40} />

                <h2>
                  موردی برای مرور نیست
                </h2>

                <p>
                  بانک زبان را بررسی یا
                  وارد کنید.
                </p>
              </div>
            )}
          </section>
        )}


        {tab === 'dictionary' && (
          <section className="panel">
            <h1>
              📚 واژه‌نامه غنی
            </h1>

            <p className="muted">
              تعریف، ترجمه، تلفظ،
              مثال، موضوع و سطح برای
              سه زبان هدف.
            </p>

            <div className="chips">
              {[
                'all',
                'عراقی',
                'لبنانی',
                'آمریکایی',
              ].map((value) => (
                <button
                  key={value}
                  className={
                    learnFilter ===
                    value
                      ? 'chip active'
                      : 'chip'
                  }
                  onClick={() =>
                    setLearnFilter(
                      value,
                    )
                  }
                >
                  {filterLabel(
                    value,
                  )}
                </button>
              ))}
            </div>

            <input
              className="search"
              value={query}
              onChange={(event) =>
                setQuery(
                  event.target.value,
                )
              }
              placeholder="واژه یا معنی را جستجو کنید…"
            />

            <div className="dictionary">
              {results
                .slice(0, 60)
                .map((item) => (
                  <article
                    key={item.id}
                  >
                    <div className="dictHead">
                      <h2>
                        {item.text}
                      </h2>

                      <span>
                        {item.level ||
                          'A1'}
                      </span>
                    </div>

                    <p>
                      {item.definition ||
                        item.translation}
                    </p>

                    <p className="phon">
                      {item.pronunciation ||
                        item.transliteration ||
                        '—'}
                    </p>

                    <p className="muted">
                      {item.example_text ||
                        ''}
                    </p>

                    <p>
                      {item.example_translation ||
                        ''}
                    </p>

                    <small>
                      {item.dialect} ·{' '}
                      {item.topic ||
                        'عمومی'}
                    </small>

                    <div className="cardActions">
                      <button
                        onClick={() =>
                          void speak(
                            item.text ||
                              '',
                            getLangCode(
                              item.dialect ||
                                '',
                              item.source_language ===
                                'en'
                                ? 'english'
                                : 'arabic',
                            ),
                          )
                        }
                      >
                        <Volume2
                          size={15}
                        />
                        تلفظ
                      </button>

                      <button
                        onClick={async () => {
                          reviewItem(
                            item.id,
                            'good',
                          );

                          await saveBankItem({
                            ...item,
                            learned: 1,
                          });

                          setToast(
                            'به مرورهای شما اضافه شد ✓',
                          );
                        }}
                      >
                        <Check size={15} />
                        یاد گرفتم
                      </button>
                    </div>
                  </article>
                ))}
            </div>
          </section>
        )}


        {tab === 'translator' && (
          <section className="panel">
            <h1>
              🌐 مترجم آموزشی
            </h1>

            <p className="muted">
              ترجمه طبیعی اول، سپس
              جزئیات آموزشی؛ نتیجه را
              هم می‌توانید بشنوید.
            </p>

            <div className="selectors">
              <label>
                جهت

                <select
                  value={
                    translationMode
                  }
                  onChange={(event) =>
                    setTranslationMode(
                      event.target
                        .value as
                        | 'target'
                        | 'persian',
                    )
                  }
                >
                  <option value="target">
                    به زبان هدف
                  </option>

                  <option value="persian">
                    به فارسی
                  </option>
                </select>
              </label>

              {translationMode ===
                'target' && (
                <label>
                  زبان هدف

                  <select
                    value={
                      targetLang
                    }
                    onChange={(event) =>
                      setTargetLang(
                        event.target
                          .value,
                      )
                    }
                  >
                    <option value="ar-IQ">
                      عربی عراقی
                    </option>

                    <option value="ar-LB">
                      عربی لبنانی
                    </option>

                    <option value="en-US">
                      انگلیسی آمریکایی
                    </option>
                  </select>
                </label>
              )}
            </div>

            <textarea
              className="translateInput"
              value={input}
              onChange={(event) =>
                setInput(
                  event.target.value,
                )
              }
              placeholder="متن فارسی، عربی یا انگلیسی را وارد کنید…"
            />

            <button
              className="primary wide"
              onClick={() =>
                void translate()
              }
              disabled={
                busy ||
                !input.trim()
              }
            >
              {busy
                ? 'در حال ترجمه…'
                : 'ترجمه'}
            </button>

            {translateOut && (
              <div className="translationResult">
                <div className="resultMain">
                  <span>
                    ترجمه طبیعی
                  </span>

                  <strong>
                    {tparts.natural}
                  </strong>
                </div>

                {tparts.literal && (
                  <details>
                    <summary>
                      ترجمه تحت‌اللفظی
                    </summary>

                    <p>
                      {
                        tparts.literal
                      }
                    </p>
                  </details>
                )}

                {tparts.pronunciation && (
                  <div className="resultRow">
                    <span>
                      تلفظ
                    </span>

                    <b>
                      {
                        tparts.pronunciation
                      }
                    </b>
                  </div>
                )}

                {tparts.note && (
                  <div className="resultRow">
                    <span>
                      نکته
                    </span>

                    <b>
                      {tparts.note}
                    </b>
                  </div>
                )}

                {tparts.example && (
                  <div className="resultRow">
                    <span>
                      مثال
                    </span>

                    <b>
                      {
                        tparts.example
                      }
                    </b>
                  </div>
                )}

                <div className="cardActions">
                  <button
                    onClick={() =>
                      void speak(
                        tparts.natural,
                        targetLang.startsWith(
                          'ar',
                        )
                          ? targetLang
                          : 'en-US',
                      )
                    }
                  >
                    <Volume2
                      size={16}
                    />
                    پخش ترجمه
                  </button>

                  <button
                    onClick={async () =>
                      setToast(
                        (await copyText(
                          translateOut,
                        ))
                          ? 'نتیجه کپی شد ✓'
                          : 'کپی ناموفق بود',
                      )
                    }
                  >
                    <Copy size={15} />
                    کپی
                  </button>
                </div>
              </div>
            )}
          </section>
        )}


        {tab === 'settings' && (
          <section className="panel settings">
            <h1>
              ⚙️ تنظیمات
            </h1>

            <div className="notice">
              <strong>
                معماری AI
              </strong>
              <br />
              اولویت:{' '}
              <b>
                Local GGUF
              </b>{' '}
              → Gemini → Groq →
              OpenRouter → Hugging
              Face → Cloudflare →
              Custom. سرویس آنلاین
              فقط مکمل است و وقتی
              اینترنت/کلید موجود باشد
              استفاده می‌شود.
            </div>


            <h3>
              مدل‌های روی گوشی
            </h3>

            <div className="notice">
              فرمت‌های قابل تشخیص:
              GGUF، ONNX، PTE،
              LiteRT-LM، Safetensors،
              PyTorch و TFLite. فقط
              Runtime سازگار اجازه
              اجرا دارد.
            </div>

            <div className="modelLibrary">
              {localModels.map(
                (model) => (
                  <div
                    className="modelCard"
                    key={model.path}
                  >
                    <div>
                      <strong>
                        {model.name}
                      </strong>

                      <small>
                        {(
                          Number(
                            model.sizeBytes,
                          ) /
                          1024 /
                          1024
                        ).toFixed(
                          0,
                        )}{' '}
                        MB ·{' '}
                        {model.format ||
                          'model'}
                      </small>
                    </div>

                    <span>
                      {model.loaded
                        ? 'فعال ✓'
                        : 'آماده'}
                    </span>

                    <button
                      onClick={async () => {
                        const result =
                          await loadLocalModel(
                            model.path,
                          );

                        setLocalModel(
                          result,
                        );

                        setLocalModels(
                          await listLocalModels(),
                        );

                        setToast(
                          result.engineReady
                            ? `مدل ${result.name} فعال شد`
                            : result.error ||
                                'بارگذاری ناموفق بود',
                        );
                      }}
                    >
                      {model.loaded
                        ? 'فعال'
                        : 'Load'}
                    </button>

                    <button
                      onClick={async () => {
                        const ok =
                          await deleteLocalModel(
                            model.path,
                          );

                        setLocalModels(
                          await listLocalModels(),
                        );

                        if (ok) {
                          setLocalModel(
                            await localModelStatus(),
                          );
                        }

                        setToast(
                          ok
                            ? 'مدل حذف شد'
                            : 'حذف ناموفق بود',
                        );
                      }}
                    >
                      <Trash2
                        size={15}
                      />
                    </button>
                  </div>
                ),
              )}

              {!localModels.length && (
                <div className="empty compact">
                  <p>
                    هنوز مدل محلی وارد
                    نشده است.
                  </p>
                </div>
              )}
            </div>


            <div className="settingsRow">
              <button
                className="primary"
                onClick={async () => {
                  const result =
                    await loadLocalModel();

                  setLocalModel(
                    result,
                  );

                  setLocalModels(
                    await listLocalModels(),
                  );

                  setToast(
                    result.engineReady
                      ? `مدل ${result.name || ''} آماده است`
                      : result.imported
                        ? `مدل ${result.name || ''} وارد شد؛ برای اجرا دوباره Load را بزنید`
                        : result.error ||
                          'مدل وارد نشد',
                  );

                  await addLog(
                    result.loaded
                      ? 'info'
                      : 'warn',
                    `local model load: ${
                      result.loaded
                        ? 'ok'
                        : result.error ||
                          'failed'
                    }`,
                  );

                  setLogs(
                    getLogs(),
                  );
                }}
              >
                <Upload size={16} />
                افزودن/بارگذاری مدل
              </button>
            </div>


            <div className="settingsRow">
              <button
                onClick={async () => {
                  try {
                    const result =
                      await LocalAI.pickTokenizer();

                    if (
                      result?.path
                    ) {
                      setEdgeTokenizerPath(
                        String(
                          result.path,
                        ),
                      );

                      setToast(
                        `Tokenizer ذخیره شد: ${
                          result.name ||
                          result.path
                        }`,
                      );
                    }
                  } catch (e: any) {
                    setToast(
                      e?.message ||
                        'انتخاب tokenizer ناموفق بود',
                    );
                  }
                }}
              >
                انتخاب tokenizer.model
                برای PTE
              </button>

              {getEdgeTokenizerPath() && (
                <span className="muted">
                  Tokenizer:{' '}
                  {getEdgeTokenizerPath()
                    .split('/')
                    .pop()}
                </span>
              )}
            </div>


            <div className="notice">
              {localModel.engineReady
                ? `🟢 مدل فعال: ${localModel.name}`
                : localModel.imported ||
                    localModel.path
                  ? `🟡 مدل وارد شده ولی آماده تولید نیست: ${
                      localModel.name ||
                      localModel.path
                    }`
                  : '⚪ مدل محلی انتخاب نشده است.'}

              <br />

              موتور حرفه‌ای مدل، فرمت
              را تشخیص می‌دهد:
              GGUF→llama.cpp؛
              ONNX→ONNX Runtime
              GenAI؛ PTE→ExecuTorch؛
              Safetensors/PyTorch→
              تبدیل یا Endpoint.
              هیچ فایل خامی با تغییر
              پسوند قابل اجرا فرض
              نمی‌شود.
            </div>


            <h3>
              🌐 Endpoint Lab حرفه‌ای
            </h3>

            <div className="notice">
              تشخیص خودکار OpenAI
              /v1، OpenAI Responses،
              Ollama، LM Studio،
              llama.cpp، LocalAI،
              vLLM و MLC. روی Android
              برای کامپیوتر دیگر از IP
              شبکه محلی استفاده کنید،
              نه localhost.
            </div>


            <div className="providerGrid">
              {[
                [
                  'ollama',
                  'Ollama',
                ],
                [
                  'lmstudio',
                  'LM Studio',
                ],
                [
                  'llamacpp',
                  'llama.cpp',
                ],
                [
                  'localai',
                  'LocalAI',
                ],
                [
                  'vllm',
                  'vLLM',
                ],
                [
                  'mlc',
                  'MLC',
                ],
              ].map(
                ([preset, label]: [string, string]) => (
                  <button
                    key={preset}
                    onClick={() => {
                      const value =
                        endpointPreset(
                          preset,
                        );

                      setCustomEndpointState(
                        value,
                      );

                      setCustomEndpoint(
                        value,
                      );
                    }}
                  >
                    {label}
                  </button>
                ),
              )}
            </div>


            <label>
              Endpoint Base URL

              <input
                value={
                  customEndpoint
                }
                onChange={(event) => {
                  setCustomEndpointState(
                    event.target.value,
                  );

                  setCustomEndpoint(
                    event.target.value,
                  );
                }}
                placeholder="http://192.168.1.10:11434"
              />
            </label>


            <label>
              Bearer Token{' '}
              <span className="muted">
                اختیاری
              </span>

              <input
                type="password"
                value={
                  customEndpointKey
                }
                onChange={(event) => {
                  setCustomEndpointKeyState(
                    event.target.value,
                  );

                  setCustomEndpointKey(
                    event.target.value,
                  );
                }}
                placeholder="برای سرورهای احراز هویت‌دار"
              />
            </label>


            <label>
              مدل Endpoint

              <input
                list="yaali-custom-models"
                value={
                  customModel
                }
                onChange={(event) => {
                  setCustomModelState(
                    event.target.value,
                  );

                  setCustomModel(
                    event.target.value,
                  );
                }}
                placeholder="خالی = انتخاب خودکار"
              />

              <datalist id="yaali-custom-models">
                {customModels.map(
                  (model) => (
                    <option
                      key={model}
                      value={model}
                    />
                  ),
                )}
              </datalist>
            </label>


            <div className="settingsRow">
              <button
                onClick={async () => {
                  const models =
                    await discoverCustomModels();

                  setCustomModels(
                    models,
                  );

                  if (
                    models.length &&
                    !customModel
                  ) {
                    const first =
                      models[0];

                    if (first) {
                      setCustomModelState(
                        first,
                      );

                      setCustomModel(
                        first,
                      );
                    }
                  }

                  setToast(
                    models.length
                      ? `${models.length} مدل کشف شد`
                      : 'مدلی پیدا نشد',
                  );
                }}
              >
                <RefreshCw
                  size={15}
                />
                کشف مدل
              </button>

              <button
                disabled={
                  endpointProbeBusy
                }
                onClick={async () => {
                  setEndpointProbeBusy(
                    true,
                  );

                  try {
                    setEndpointProbe(
                      await inspectCustomEndpoint(),
                    );
                  } finally {
                    setEndpointProbeBusy(
                      false,
                    );
                  }
                }}
              >
                {endpointProbeBusy
                  ? 'Probe…'
                  : 'Probe Endpoint'}
              </button>

              <button
                onClick={async () => {
                  const result =
                    await testProvider(
                      'custom',
                    );

                  setToast(
                    result.ok
                      ? 'Chat endpoint OK ✓'
                      : `خطا: ${result.message}`,
                  );
                }}
              >
                تست Chat
              </button>
            </div>


            {endpointProbe && (
              <div className="notice">
                <b>
                  {endpointProbe.ok
                    ? '🟢'
                    : '🔴'}{' '}
                  {
                    endpointProbe.message
                  }
                </b>

                <br />

                Protocol:{' '}
                {endpointProbe.protocols.join(
                  ', ',
                ) || 'unknown'}

                <br />

                Capabilities:{' '}
                {endpointProbe.capabilities.join(
                  ', ',
                ) || 'none'}

                <br />

                Chat:{' '}
                {endpointProbe.chatPath ||
                  'unknown'}

                <br />

                Models:{' '}
                {endpointProbe.models
                  .slice(0, 10)
                  .join(
                    ', ',
                  ) || 'none'}
              </div>
            )}


            <h3>
              🧠 مرکز مدل‌ها و اتصال
              هوش مصنوعی
            </h3>

            <div className="notice">
              این بخش مدل‌های محلی و
              سرویس‌های ابری را از هم
              جدا نگه می‌دارد. مدل
              غیر-GGUF فقط وقتی Runtime
              واقعی آن نصب/متصل باشد
              اجرا می‌شود؛ تغییر پسوند
              فایل به‌عنوان تبدیل مدل
              پذیرفته نیست.
            </div>

            <div className="settingsRow">
              <button
                onClick={async () => {
                  setModelDiscoveryBusy(
                    true,
                  );

                  try {
                    const models =
                      await discoverAllConfiguredModels();

                    setDiscoveredModels(
                      models,
                    );

                    setToast(
                      `${models.length} مدل از Providerهای تنظیم‌شده کشف شد`,
                    );
                  } finally {
                    setModelDiscoveryBusy(
                      false,
                    );
                  }
                }}
              >
                <RefreshCw
                  size={15}
                />

                {modelDiscoveryBusy
                  ? 'در حال کشف…'
                  : 'کشف همه مدل‌ها'}
              </button>
            </div>


            {discoveredModels.length >
              0 && (
              <div className="modelDiscovery">
                {discoveredModels
                  .slice(0, 40)
                  .map((model) => (
                    <div
                      key={`${model.provider}:${model.id}`}
                    >
                      <b>
                        {model.id}
                      </b>

                      <small>
                        {providerLabel(
                          model.provider,
                        )}

                        {model.contextWindow
                          ? ` · ${model.contextWindow.toLocaleString(
                              'en-US',
                            )} ctx`
                          : ''}
                      </small>
                    </div>
                  ))}
              </div>
            )}


            <h3>
              🛡️ مرکز حریم خصوصی و
              سلامت دستگاه
            </h3>

            <div className="notice">
              گزارش‌های عیب‌یابی و
              خروجی‌ها باید بدون کلید
              API صادر شوند. کلیدها در
              این نسخه همچنان با لایه
              ذخیره‌سازی فعلی نگهداری
              می‌شوند؛ برای امنیت
              سخت‌افزاری Android،
              مرحله بعدی Keystore است.
            </div>

            <div className="providerGrid">
              <span>
                🔐 Secretها:{' '}
                {
                  privacy.secretsConfigured
                }
              </span>

              <span>
                🗂️ Storage keys:{' '}
                {
                  privacy.localStorageKeys
                }
              </span>

              <span>
                📱 Native:{' '}
                {privacy.native
                  ? 'Yes'
                  : 'No'}
              </span>

              <span>
                📜 Logs:{' '}
                {privacy.logsCount}
              </span>
            </div>


            <div className="settingsRow">
              <button
                onClick={() => {
                  const safe =
                    redactSecrets(
                      JSON.stringify(
                        privacyReport(),
                        null,
                        2,
                      ),
                    );

                  downloadJson(
                    'ya-ali-privacy-report.json',
                    safe,
                  );
                }}
              >
                گزارش امن حریم خصوصی
              </button>

              <button
                onClick={() => {
                  const count =
                    clearNonSecretAppCache();

                  setPrivacy(
                    privacyReport(),
                  );

                  setToast(
                    `${count} مورد cache پاک شد ✓`,
                  );
                }}
              >
                پاک‌سازی Cache
              </button>

              <button
                onClick={() => {
                  clearDiagnosticData();

                  setPrivacy(
                    privacyReport(),
                  );

                  setLogs([]);

                  setToast(
                    'داده‌های تشخیصی پاک شد ✓',
                  );
                }}
              >
                پاک‌سازی Diagnostics
              </button>
            </div>


            <div className="notice">
              سلامت دستگاه:{' '}
              {deviceHealth
                ? `${
                    deviceHealth.online
                      ? 'آنلاین'
                      : 'آفلاین'
                  } · CPU ${
                    deviceHealth.hardwareConcurrency ||
                    '?'
                  } · ${
                    deviceHealth.viewport.width
                  }×${
                    deviceHealth.viewport.height
                  }${
                    deviceHealth.storage
                      ? ` · Storage ${deviceHealth.storage.usageMB}/${deviceHealth.storage.quotaMB} MB`
                      : ''
                  }`
                : 'در حال بررسی…'}
            </div>


            <div className="settingsRow">
              <button
                disabled={
                  benchmarkBusy
                }
                onClick={async () => {
                  setBenchmarkBusy(
                    true,
                  );

                  try {
                    const result =
                      await benchmarkLocalModel();

                    setBenchmark(
                      result,
                    );

                    await addLog(
                      result.ok
                        ? 'info'
                        : 'warn',
                      `local benchmark ${
                        result.ok
                          ? 'OK'
                          : 'FAILED'
                      } ${
                        result.elapsedMs
                      }ms ${
                        result.charsPerSecond
                      } chars/s`,
                    );

                    setLogs(
                      getLogs(),
                    );
                  } finally {
                    setBenchmarkBusy(
                      false,
                    );
                  }
                }}
              >
                <BarChart3
                  size={15}
                />

                {benchmarkBusy
                  ? 'در حال Benchmark…'
                  : 'Benchmark مدل محلی'}
              </button>

              {benchmark && (
                <span className="muted">
                  {benchmark.ok
                    ? `${benchmark.elapsedMs}ms · ${benchmark.charsPerSecond} chars/s · ${benchmark.runtime}`
                    : benchmark.error}
                </span>
              )}
            </div>


            <div className="notice">
              Edge Runtime:{' '}
              {edgeCaps
                ? 'اطلاعات Runtime دریافت شد'
                : 'در حال بررسی…'}
            </div>


            <h3>
              AI آنلاین
            </h3>

            <label>
              OpenRouter

              <input
                type="password"
                value={orKey}
                onChange={(event) => {
                  setOrKey(
                    event.target.value,
                  );

                  setOpenRouterApiKey(
                    event.target.value,
                  );
                }}
                placeholder="کلید OpenRouter"
              />
            </label>

            <label>
              Gemini Free Tier

              <input
                type="password"
                value={gemKey}
                onChange={(event) => {
                  setGemKey(
                    event.target.value,
                  );

                  setGeminiApiKey(
                    event.target.value,
                  );
                }}
                placeholder="کلید Gemini"
              />
            </label>

            <label>
              Groq

              <input
                type="password"
                value={groqKey}
                onChange={(event) => {
                  setGroqKey(
                    event.target.value,
                  );

                  setGroqApiKey(
                    event.target.value,
                  );
                }}
                placeholder="کلید Groq"
              />
            </label>

            <label>
              Hugging Face Inference

              <input
                type="password"
                value={hfKey}
                onChange={(event) => {
                  setHfKey(
                    event.target.value,
                  );

                  setHuggingFaceApiKey(
                    event.target.value,
                  );
                }}
                placeholder="hf_…"
              />
            </label>

            <label>
              Cloudflare Account ID

              <input
                value={cfAccount}
                onChange={(event) => {
                  setCfAccount(
                    event.target.value,
                  );

                  setCloudflareAccount(
                    event.target.value,
                  );
                }}
                placeholder="Account ID"
              />
            </label>

            <label>
              Cloudflare API Token

              <input
                type="password"
                value={cfToken}
                onChange={(event) => {
                  setCfToken(
                    event.target.value,
                  );

                  setCloudflareToken(
                    event.target.value,
                  );
                }}
                placeholder="API Token"
              />
            </label>

            <label>
              Cloudflare Model

              <input
                value={cfModel}
                onChange={(event) => {
                  setCfModel(
                    event.target.value,
                  );

                  setCloudflareModel(
                    event.target.value,
                  );
                }}
                placeholder="@cf/meta/llama-3.1-8b-instruct"
              />
            </label>


            <h3>
              گفتار
            </h3>

            <div className="notice">
              {speechInfo?.onDeviceAvailable
                ? '🟢 On-device Speech Recognition روی این دستگاه موجود است.'
                : '🟡 On-device Speech Recognition گزارش نشده؛ برنامه از سرویس گفتار سیستم به‌عنوان fallback استفاده می‌کند.'}

              <br />

              وضعیت سرویس:{' '}
              {speechInfo?.available
                ? 'در دسترس'
                : 'نامشخص/غیرفعال'}
            </div>

            <label>
              سرعت تلفظ:{' '}
              {speechSpeed.toFixed(
                2,
              )}

              <input
                type="range"
                min=".5"
                max="1.5"
                step=".05"
                value={
                  speechSpeed
                }
                onChange={(event) => {
                  const value =
                    Number(
                      event.target
                        .value,
                    );

                  setSpeed(value);
                  setSpeechSpeed(
                    value,
                  );
                }}
              />
            </label>


            <div className="providerGrid">
              {providers.map(
                (provider) => (
                  <span
                    key={provider}
                  >
                    ✓{' '}
                    {providerLabel(
                      provider,
                    )}
                  </span>
                ),
              )}

              {!providers.length && (
                <span>
                  ⚠️ هنوز سرویس آنلاین
                  تنظیم نشده
                </span>
              )}
            </div>


            <div className="settingsRow">
              <button
                onClick={async () => {
                  for (const provider of providers) {
                    const result =
                      await testProvider(
                        provider,
                      );

                    await addLog(
                      result.ok
                        ? 'info'
                        : 'error',
                      `${
                        providerLabel(
                          provider,
                        )
                      } test ${
                        result.ok
                          ? 'OK'
                          : 'FAILED'
                      } ${
                        result.latencyMs
                      }ms — ${
                        result.message
                      }`,
                    );
                  }

                  setLogs(
                    getLogs(),
                  );

                  setToast(
                    'تست همه سرویس‌ها انجام شد',
                  );
                }}
              >
                تست اتصال AI
              </button>
            </div>


            <h3>
              🎙️ Voice Pack Manager ·
              بسته‌های صوتی لهجه
            </h3>

            <div className="notice">
              بسته‌های صوتی خارج از APK
              نگهداری می‌شوند تا حجم
              برنامه پایین بماند. مدیر
              بسته وضعیت دانلود، نسخه،
              اندازه و حذف را کنترل
              می‌کند. برای لهجه‌های
              عربی فقط منابعی که مجوز
              و منبع روشن دارند باید
              به‌عنوان دانلود رسمی ثبت
              شوند.
            </div>

            <div className="voicePackGrid">
              {voicePacks.map(
                (pack) => (
                  <div
                    className="voicePackCard"
                    key={pack.id}
                  >
                    <div>
                      <strong>
                        {
                          pack.nameFa
                        }
                      </strong>

                      <small>
                        {pack.locale} ·{' '}
                        {pack.kind} ·{' '}
                        {pack.status ===
                        'installed'
                          ? 'نصب‌شده'
                          : pack.status ===
                              'downloading'
                            ? 'در حال دانلود'
                            : 'آماده'}
                      </small>

                      <p>
                        {
                          pack.description
                        }
                      </p>
                    </div>

                    <div className="settingsRow">
                      <button
                        disabled={
                          voiceBusy ===
                          pack.id
                        }
                        onClick={async () => {
                          setVoiceBusy(
                            pack.id,
                          );

                          try {
                            await downloadVoicePack(
                              pack.id,
                              (percent) =>
                                setToast(
                                  `${pack.nameFa}: ${percent}%`,
                                ),
                            );

                            setVoicePacks(
                              listVoicePacks(),
                            );

                            setToast(
                              `${pack.nameFa} نصب شد ✓`,
                            );
                          } catch (e: any) {
                            setToast(
                              e?.message ||
                                'دانلود ناموفق بود',
                            );
                          } finally {
                            setVoiceBusy(
                              '',
                            );
                          }
                        }}
                      >
                        {voiceBusy ===
                        pack.id
                          ? 'دانلود…'
                          : 'دانلود'}
                      </button>

                      {pack.status ===
                        'installed' && (
                        <button
                          onClick={async () => {
                            await deleteDownloadedVoicePack(
                              pack.id,
                            );

                            setVoicePacks(
                              listVoicePacks(),
                            );

                            setToast(
                              'بسته حذف شد',
                            );
                          }}
                        >
                          <Trash2
                            size={15}
                          />
                        </button>
                      )}
                    </div>
                  </div>
                ),
              )}
            </div>


            <div className="settingsRow">
              <button
                onClick={() =>
                  downloadJson(
                    'ya-ali-voice-packs.json',
                    exportVoicePackManifest(),
                  )
                }
              >
                <Download
                  size={15}
                />
                خروجی Manifest
              </button>
            </div>


            <h3>
              🗣️ آموزش لهجه
            </h3>

            <div className="selectors">
              <label>
                لهجه هدف

                <select
                  value={
                    dialectTarget
                  }
                  onChange={(event) =>
                    setDialectTarget(
                      event.target
                        .value,
                    )
                  }
                >
                  {DIALECT_PROFILES.map(
                    (profile) => (
                      <option
                        key={
                          profile.id
                        }
                        value={
                          profile.id
                        }
                      >
                        {
                          profile.labelFa
                        }
                      </option>
                    ),
                  )}
                </select>
              </label>
            </div>

            <div className="notice">
              {buildDialectPrompt(
                dialectTarget,
              )}

              <br />

              این پروفایل در آینده
              می‌تواند به تحلیل
              مکالمه، ترجمه، STT/TTS و
              SRS متصل شود.
            </div>


            <h3>
              بانک زبان
            </h3>

            <div className="notice">
              ورود JSON اکنون هم
              خروجی خود Ya Ali و هم
              قالب‌های رایج واژه‌نامه
              را می‌خواند. برای
              فایل‌هایی که لهجه داخل
              هر رکورد ندارند، لهجه را
              قبل از ورود انتخاب کنید.
            </div>

            <div className="importBankBox">
              <label>
                لهجه پیش‌فرض فایل

                <select
                  value={
                    importDialect
                  }
                  onChange={(event) =>
                    setImportDialect(
                      event.target
                        .value as
                        | 'iraqi'
                        | 'lebanese'
                        | 'gulf'
                        | 'saudi'
                        | 'egyptian'
                        | 'msa'
                        | 'american',
                    )
                  }
                >
                  <option value="iraqi">
                    عربی عراقی
                  </option>

                  <option value="lebanese">
                    عربی لبنانی
                  </option>

                  <option value="american">
                    انگلیسی آمریکایی
                  </option>
                </select>
              </label>

              <div className="settingsRow">
                <button
                  className="primary"
                  onClick={() =>
                    fileRef.current?.click()
                  }
                >
                  <Upload />
                  وارد کردن JSON
                </button>

                <button
                  onClick={() =>
                    downloadJson(
                      'ya-ali-language-bank.json',
                      exportBank(),
                    )
                  }
                >
                  <Download />
                  خروجی بانک
                </button>
              </div>
            </div>


            <input
              ref={fileRef}
              type="file"
              accept=".json,application/json"
              hidden
              onChange={async (
                event,
              ) => {
                const file =
                  event.target
                    .files?.[0];

                event.currentTarget.value =
                  '';

                if (!file) {
                  return;
                }

                try {
                  const payload =
                    JSON.parse(
                      await file.text(),
                    );

                  const fallback =
                    importDialect ===
                    'iraqi'
                      ? 'عراقی'
                      : importDialect ===
                          'lebanese'
                        ? 'لبنانی'
                        : 'آمریکایی';

                  const count =
                    await importBank(
                      payload,
                      fallback,
                    );

                  setBank(
                    getBankItems(),
                  );

                  await addLog(
                    count
                      ? 'info'
                      : 'warn',
                    `bank import: ${count} item(s) from ${file.name}`,
                  );

                  setLogs(
                    getLogs(),
                  );

                  setToast(
                    count
                      ? `${count} مورد به بانک اضافه شد ✓`
                      : 'هیچ رکورد قابل‌واردی پیدا نشد؛ لهجه/ساختار JSON را بررسی کنید.',
                  );
                } catch (e: any) {
                  setToast(
                    `فایل JSON معتبر نیست: ${
                      e?.message || ''
                    }`,
                  );
                }
              }}
            />
          </section>
        )}


        {tab === 'diagnostics' && (
          <section className="panel diagnostics">
            <h1>
              🛠 عیب‌یابی حرفه‌ای
            </h1>

            <p className="muted">
              عیب‌یابی یکپارچه برای
              Android، STT/TTS، Local
              AI، مدل‌ها، Providerها،
              شبکه، Storage و Voice
              Packها.
            </p>

            <div className="providerGrid">
              <span>
                Privacy secrets:{' '}
                {
                  privacy.secretsConfigured
                }
              </span>

              <span>
                Network:{' '}
                {deviceHealth?.online
                  ? 'Online'
                  : 'Offline'}
              </span>

              {benchmark && (
                <span>
                  Benchmark:{' '}
                  {benchmark.ok
                    ? `${benchmark.elapsedMs}ms / ${benchmark.charsPerSecond} chars/s`
                    : 'failed'}
                </span>
              )}
            </div>


            <div className="settingsRow">
              <button
                className="primary"
                disabled={
                  diagRunning
                }
                onClick={async () => {
                  setDiagRunning(
                    true,
                  );

                  try {
                    const result =
                      await runDiagnostics();

                    setDiagChecks(
                      result,
                    );

                    await addLog(
                      'info',
                      `diagnostics completed: ${
                        diagnosticsSummary(
                          result,
                        ).ok
                      }/${result.length} ok`,
                    );

                    setLogs(
                      getLogs(),
                    );
                  } finally {
                    setDiagRunning(
                      false,
                    );
                  }
                }}
              >
                <RefreshCw
                  size={15}
                />

                {diagRunning
                  ? 'در حال بررسی…'
                  : 'اجرای کامل عیب‌یابی'}
              </button>

              <button
                onClick={() => {
                  const payload =
                    redactSecrets(
                      JSON.stringify(
                        diagnosticsSummary(
                          diagChecks,
                        ),
                        null,
                        2,
                      ),
                    );

                  downloadJson(
                    'ya-ali-diagnostics-report.json',
                    payload,
                  );
                }}
              >
                <Download
                  size={15}
                />
                گزارش
              </button>

              <button
                onClick={async () => {
                  const value =
                    await getNativeLogcat();

                  setNativeLogcat(
                    value,
                  );

                  setToast(
                    'Logcat تازه شد',
                  );
                }}
              >
                <RefreshCw
                  size={15}
                />
                Logcat
              </button>

              <button
                onClick={() => {
                  clearLogs();
                  setLogs([]);
                }}
              >
                <Trash2
                  size={15}
                />
                پاک کردن لاگ
              </button>
            </div>


            {diagChecks.length >
              0 && (
              <div className="diagGrid">
                {diagChecks.map(
                  (check) => (
                    <article
                      key={
                        check.id
                      }
                      className={`diagCard ${check.severity}`}
                    >
                      <div>
                        <strong>
                          {
                            check.title
                          }
                        </strong>

                        <span>
                          {check.ok
                            ? '✓'
                            : '!'}
                        </span>
                      </div>

                      <p>
                        {
                          check.message
                        }
                      </p>

                      {check.latencyMs !==
                        undefined && (
                        <small>
                          {
                            check.latencyMs
                          }{' '}
                          ms
                        </small>
                      )}
                    </article>
                  ),
                )}
              </div>
            )}


            <h2>
              رویدادهای برنامه
            </h2>

            <div className="logbox">
              {logs
                .slice()
                .reverse()
                .map(
                  (log, index) => (
                    <div
                      key={index}
                    >
                      [{log.time}] [
                      {log.level}] {log.message}
                    </div>
                  ),
                )}
            </div>


            <h2>
              Android Logcat
            </h2>

            <pre className="logbox native">
              {nativeLogcat ||
                'برای دریافت Logcat روی دکمه بالا بزنید.'}
            </pre>


            <h2>
              وضعیت Local AI
            </h2>

            <div className="notice">
              {localModel.engineReady
                ? `🟢 ${
                    localModel.name ||
                    'مدل محلی'
                  }`
                : localModel.error ||
                  'مدل محلی آماده نیست.'}

              {localModel.generating && (
                <>
                  <br />
                  در حال تولید…
                </>
              )}
            </div>
          </section>
        )}
      </main>


      <nav className="bottomNav">
        {nav.map(
          ([id, label, Icon]) => (
            <button
              key={id}
              className={
                tab === id
                  ? 'active'
                  : ''
              }
              onClick={() =>
                setTab(id)
              }
            >
              <Icon size={21} />
              <span>
                {label}
              </span>
            </button>
          ),
        )}
      </nav>


      {toast && (
        <div className="toast">
          {toast}

          <button
            onClick={() =>
              setToast('')
            }
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
