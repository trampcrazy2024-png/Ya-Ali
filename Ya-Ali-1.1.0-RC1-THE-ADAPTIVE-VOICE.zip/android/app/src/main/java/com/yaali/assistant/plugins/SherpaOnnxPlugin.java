package com.yaali.assistant.plugins;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import com.k2fsa.sherpa.onnx.GenerationConfig;
import com.k2fsa.sherpa.onnx.OfflineTts;
import com.k2fsa.sherpa.onnx.OfflineTtsConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig;
import com.k2fsa.sherpa.onnx.OnlineModelConfig;
import com.k2fsa.sherpa.onnx.OnlineRecognizer;
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig;
import com.k2fsa.sherpa.onnx.OnlineStream;
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Real offline speech runtime for Ya-Ali.
 *
 * STT: Sherpa-ONNX streaming transducer + Android AudioRecord.
 * TTS: Sherpa-ONNX VITS/Piper-compatible ONNX voice model + AudioTrack.
 *
 * Models are user-managed and never downloaded implicitly by this plugin.
 */
@CapacitorPlugin(name = "SherpaOnnx")
public class SherpaOnnxPlugin extends Plugin {
    private static final int SAMPLE_RATE = 16000;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile OnlineRecognizer recognizer;
    private volatile OnlineStream stream;
    private volatile AudioRecord recorder;
    private volatile PluginCall activeSttCall;
    private final AtomicBoolean recording = new AtomicBoolean(false);

    @PluginMethod
    public void capabilities(PluginCall call) {
        JSObject out = new JSObject();
        out.put("available", true);
        out.put("stt", true);
        out.put("tts", true);
        out.put("offline", true);
        out.put("sampleRate", SAMPLE_RATE);
        out.put("version", "sherpa-onnx-1.13.7");
        call.resolve(out);
    }

    @PluginMethod
    public void startStt(PluginCall call) {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            call.reject("RECORD_AUDIO permission is required");
            return;
        }
        String modelDir = call.getString("modelDir", "");
        String encoder = call.getString("encoder", modelDir + "/encoder.onnx");
        String decoder = call.getString("decoder", modelDir + "/decoder.onnx");
        String joiner = call.getString("joiner", modelDir + "/joiner.onnx");
        String tokens = call.getString("tokens", modelDir + "/tokens.txt");
        if (modelDir.isEmpty() || encoder.isEmpty() || decoder.isEmpty() || joiner.isEmpty() || tokens.isEmpty()) {
            call.reject("modelDir or streaming transducer model paths are missing");
            return;
        }
        if (recording.get()) {
            call.reject("STT is already recording");
            return;
        }

        executor.execute(() -> {
            try {
                OnlineTransducerModelConfig transducer = OnlineTransducerModelConfig.builder()
                        .setEncoder(encoder)
                        .setDecoder(decoder)
                        .setJoiner(joiner)
                        .build();
                OnlineModelConfig model = OnlineModelConfig.builder()
                        .setTransducer(transducer)
                        .setTokens(tokens)
                        .setNumThreads(Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() / 2)))
                        .setDebug(false)
                        .build();
                OnlineRecognizerConfig config = OnlineRecognizerConfig.builder()
                        .setOnlineModelConfig(model)
                        .setDecodingMethod("greedy_search")
                        .build();

                OnlineRecognizer localRecognizer = new OnlineRecognizer(config);
                OnlineStream localStream = localRecognizer.createStream();
                int minBuffer = AudioRecord.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                if (minBuffer <= 0) throw new IllegalStateException("AudioRecord buffer size unavailable");
                AudioRecord localRecorder = new AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        Math.max(minBuffer * 2, SAMPLE_RATE / 2));
                if (localRecorder.getState() != AudioRecord.STATE_INITIALIZED) {
                    localRecorder.release();
                    throw new IllegalStateException("AudioRecord initialization failed");
                }

                recognizer = localRecognizer;
                stream = localStream;
                recorder = localRecorder;
                recording.set(true);
                activeSttCall = call;
                main.post(() -> notifyListeners("sttStarted", new JSObject().put("recording", true).put("sampleRate", SAMPLE_RATE)));
                main.postDelayed(() -> { if (recording.get()) recording.set(false); }, 30000L);

                localRecorder.startRecording();
                short[] pcm = new short[2048];
                float[] samples = new float[2048];
                while (recording.get()) {
                    int read = localRecorder.read(pcm, 0, pcm.length, AudioRecord.READ_BLOCKING);
                    if (read <= 0) continue;
                    for (int i = 0; i < read; i++) samples[i] = pcm[i] / 32768.0f;
                    localStream.acceptWaveform(samples, SAMPLE_RATE);
                    while (localRecognizer.isReady(localStream)) localRecognizer.decode(localStream);
                    String text = localRecognizer.getResult(localStream).getText();
                    if (text != null && !text.trim().isEmpty()) {
                        JSObject event = new JSObject();
                        event.put("text", text.trim());
                        event.put("final", false);
                        notifyListeners("sttPartial", event);
                    }
                }
            } catch (Throwable e) {
                recording.set(false);
                cleanupStt();
                PluginCall pending = activeSttCall;
                activeSttCall = null;
                main.post(() -> { if (pending != null) pending.reject("Sherpa-ONNX STT failed: " + message(e)); else call.reject("Sherpa-ONNX STT failed: " + message(e)); });
            }
        });
    }

    @PluginMethod
    public void stopStt(PluginCall call) {
        recording.set(false);
        executor.execute(() -> {
            try {
                OnlineRecognizer r = recognizer;
                OnlineStream s = stream;
                String text = "";
                if (r != null && s != null) {
                    float[] tail = new float[(int) (0.8f * SAMPLE_RATE)];
                    s.acceptWaveform(tail, SAMPLE_RATE);
                    while (r.isReady(s)) r.decode(s);
                    r.inputFinished(s);
                    while (r.isReady(s)) r.decode(s);
                    text = r.getResult(s).getText();
                }
                JSObject out = new JSObject();
                out.put("recording", false);
                out.put("text", text == null ? "" : text.trim());
                PluginCall pending = activeSttCall;
                activeSttCall = null;
                if (pending != null) pending.resolve(out);
                call.resolve(new JSObject().put("recording", false));
            } catch (Throwable e) {
                call.reject("Sherpa-ONNX STT stop failed: " + message(e));
            } finally {
                cleanupStt();
            }
        });
    }

    @PluginMethod
    public void speak(PluginCall call) {
        String text = call.getString("text", "");
        String model = call.getString("model", "");
        String tokens = call.getString("tokens", "");
        String dataDir = call.getString("dataDir", "");
        String lexicon = call.getString("lexicon", "");
        int sid = call.getInt("sid", 0);
        double speed = Math.max(0.5, Math.min(2.0, call.getDouble("speed", 1.0)));
        if (text.trim().isEmpty() || model.isEmpty() || tokens.isEmpty()) {
            call.reject("text, model and tokens are required for offline TTS");
            return;
        }
        executor.execute(() -> {
            OfflineTts tts = null;
            try {
                OfflineTtsVitsModelConfig vits = OfflineTtsVitsModelConfig.builder()
                        .setModel(model)
                        .setTokens(tokens)
                        .setDataDir(dataDir)
                        .setLexicon(lexicon)
                        .build();
                OfflineTtsModelConfig modelConfig = OfflineTtsModelConfig.builder()
                        .setVits(vits)
                        .setNumThreads(Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() / 2)))
                        .setDebug(false)
                        .build();
                OfflineTtsConfig config = OfflineTtsConfig.builder().setModel(modelConfig).build();
                tts = new OfflineTts(config);
                GenerationConfig generation = new GenerationConfig();
                generation.setSid(sid);
                generation.setSpeed((float) speed);
                generation.setSilenceScale(0.2f);
                com.k2fsa.sherpa.onnx.GeneratedAudio audio = tts.generateWithConfigAndCallback(text, generation, samples -> 1);
                playPcm(audio.getSamples(), audio.getSampleRate());
                JSObject out = new JSObject();
                out.put("ok", true);
                out.put("sampleRate", audio.getSampleRate());
                out.put("samples", audio.getSamples().length);
                call.resolve(out);
            } catch (Throwable e) {
                call.reject("Sherpa-ONNX TTS failed: " + message(e));
            } finally {
                if (tts != null) try { tts.release(); } catch (Throwable ignored) {}
            }
        });
    }

    private void playPcm(float[] samples, int sampleRate) {
        int[] pcm = new int[samples.length];
        for (int i = 0; i < samples.length; i++) {
            float v = Math.max(-1f, Math.min(1f, samples[i]));
            pcm[i] = Math.round(v * 32767f);
        }
        short[] out = new short[pcm.length];
        for (int i = 0; i < pcm.length; i++) out[i] = (short) pcm[i];
        int min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, Math.max(min, out.length * 2), AudioTrack.MODE_STREAM);
        try {
            track.play();
            track.write(out, 0, out.length);
            track.stop();
        } finally {
            track.release();
        }
    }

    private void cleanupStt() {
        AudioRecord r = recorder;
        recorder = null;
        if (r != null) { try { r.stop(); } catch (Throwable ignored) {} try { r.release(); } catch (Throwable ignored) {} }
        OnlineStream s = stream;
        stream = null;
        if (s != null) try { s.release(); } catch (Throwable ignored) {}
        OnlineRecognizer rec = recognizer;
        recognizer = null;
        if (rec != null) try { rec.release(); } catch (Throwable ignored) {}
    }

    private static String message(Throwable e) {
        return e.getMessage() == null ? e.toString() : e.getMessage();
    }

    @Override protected void handleOnDestroy() {
        recording.set(false);
        cleanupStt();
        executor.shutdownNow();
        super.handleOnDestroy();
    }
}
