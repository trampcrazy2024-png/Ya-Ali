package com.yaali.assistant.plugins;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;

/**
 * Crash-safe Android STT bridge.
 *
 * We prefer Android's on-device recognizer when the device advertises one.
 * If that path cannot be created, we fall back to the system recognition
 * activity instead of allowing an OEM RecognitionService failure to crash
 * the application.
 */
@CapacitorPlugin(name = "NativeSTT")
public class NativeSTTPlugin extends Plugin {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private PluginCall pendingCall;
    private Runnable timeoutTask;
    private boolean usingOnDevice = false;

    @PluginMethod
    public void listen(PluginCall call) {
        mainHandler.post(() -> startListening(call));
    }

    private void startListening(PluginCall call) {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            call.reject("مجوز میکروفن داده نشده است. در تنظیمات Android دسترسی Microphone را فعال کنید.");
            return;
        }

        if (pendingCall != null) {
            call.reject("تشخیص گفتار دیگری در حال اجراست.");
            return;
        }

        final String lang = call.getString("lang", "fa-IR");
        pendingCall = call;

        // Direct SpeechRecognizer is useful because it can explicitly select
        // the on-device service. All calls are made on the main thread.
        boolean serviceAvailable = false;
        try {
            serviceAvailable = SpeechRecognizer.isRecognitionAvailable(getContext());
        } catch (Throwable ignored) {}

        if (!serviceAvailable) {
            startRecognizerActivity(lang);
            return;
        }

        if (createSafeRecognizer()) {
            Intent intent = buildIntent(lang);
            try {
                recognizer.startListening(intent);
                scheduleTimeout();
            } catch (Throwable directStartError) {
                destroyRecognizer();
                startRecognizerActivity(lang);
            }
        } else {
            startRecognizerActivity(lang);
        }
    }

    private Intent buildIntent(String lang) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "یا علی — صحبت کنید");
        // Do not force offline. Some phones report an on-device recognizer but
        // still require model provisioning; the service itself decides whether
        // offline recognition is possible.
        if (Build.VERSION.SDK_INT >= 23) {
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, usingOnDevice);
        }
        return intent;
    }

    private boolean createSafeRecognizer() {
        destroyRecognizer();
        try {
            usingOnDevice = Build.VERSION.SDK_INT >= 31
                    && SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext());
        } catch (Throwable ignored) {
            usingOnDevice = false;
        }

        try {
            if (usingOnDevice) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(getContext());
            } else {
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
            }
            recognizer.setRecognitionListener(listener);
            return true;
        } catch (Throwable first) {
            destroyRecognizer();
            try {
                usingOnDevice = false;
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(listener);
                return true;
            } catch (Throwable ignored) {
                destroyRecognizer();
                return false;
            }
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}

        @Override public void onError(int error) {
            // Do not call cancel() from inside onError(). Several OEM speech
            // services recursively dispatch callbacks when cancel is called,
            // which can crash the host Activity.
            clearTimeout();
            PluginCall call = pendingCall;
            pendingCall = null;
            destroyRecognizer();
            if (call != null) call.reject(errorMessage(error));
        }

        @Override public void onResults(Bundle results) {
            clearTimeout();
            ArrayList<String> values = results == null
                    ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            PluginCall call = pendingCall;
            pendingCall = null;
            if (call == null) {
                destroyRecognizer();
                return;
            }
            if (values == null || values.isEmpty() || values.get(0) == null
                    || values.get(0).trim().isEmpty()) {
                destroyRecognizer();
                call.reject("هیچ گفتاری تشخیص داده نشد.");
                return;
            }
            JSObject out = new JSObject();
            out.put("text", values.get(0).trim());
            out.put("mode", usingOnDevice ? "on-device" : "system-service");
            JSArray alternatives = new JSArray();
            for (String value : values) if (value != null && !value.trim().isEmpty()) alternatives.put(value.trim());
            out.put("alternatives", alternatives);
            destroyRecognizer();
            call.resolve(out);
        }
    };

    private void startRecognizerActivity(String lang) {
        if (pendingCall == null) return;
        try {
            Intent intent = buildIntent(lang);
            usingOnDevice = false;
            startActivityForResult(pendingCall, intent, "speechResult");
            scheduleTimeout();
        } catch (Throwable e) {
            PluginCall call = pendingCall;
            pendingCall = null;
            clearTimeout();
            if (call != null) call.reject("سرویس تشخیص گفتار Android قابل اجرا نیست: " + safeMessage(e));
        }
    }

    @ActivityCallback
    private void speechResult(PluginCall call, ActivityResult result) {
        clearTimeout();
        if (call == null) return;
        if (result == null || result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            if (pendingCall == call) pendingCall = null;
            call.reject("تشخیص گفتار لغو شد یا سرویس گفتار در دسترس نبود.");
            return;
        }
        ArrayList<String> values = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (pendingCall == call) pendingCall = null;
        if (values == null || values.isEmpty() || values.get(0) == null || values.get(0).trim().isEmpty()) {
            call.reject("هیچ گفتاری تشخیص داده نشد.");
            return;
        }
        JSObject out = new JSObject();
        out.put("text", values.get(0).trim());
        out.put("mode", "system-activity");
        JSArray alternatives = new JSArray();
        for (String value : values) if (value != null && !value.trim().isEmpty()) alternatives.put(value.trim());
        out.put("alternatives", alternatives);
        call.resolve(out);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        mainHandler.post(() -> {
            clearTimeout();
            PluginCall pending = pendingCall;
            pendingCall = null;
            if (recognizer != null) {
                try { recognizer.cancel(); } catch (Throwable ignored) {}
                destroyRecognizer();
            }
            if (pending != null) pending.reject("تشخیص گفتار متوقف شد.");
            call.resolve();
        });
    }

    private void scheduleTimeout() {
        clearTimeout();
        timeoutTask = () -> {
            PluginCall call = pendingCall;
            pendingCall = null;
            if (recognizer != null) {
                try { recognizer.cancel(); } catch (Throwable ignored) {}
            }
            destroyRecognizer();
            if (call != null) call.reject("تشخیص گفتار بیش از ۳۰ ثانیه طول کشید.");
        };
        mainHandler.postDelayed(timeoutTask, 30000L);
    }

    private void clearTimeout() {
        if (timeoutTask != null) {
            mainHandler.removeCallbacks(timeoutTask);
            timeoutTask = null;
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Throwable ignored) {}
            recognizer = null;
        }
    }

    private String errorMessage(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "خطای میکروفن یا ضبط صدا.";
            case SpeechRecognizer.ERROR_CLIENT: return "خطای سرویس تشخیص گفتار Android.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "مجوز میکروفن داده نشده است.";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "زبان انتخاب‌شده پشتیبانی نمی‌شود.";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "مدل زبان انتخاب‌شده روی دستگاه موجود نیست.";
            case SpeechRecognizer.ERROR_NETWORK: return "سرویس گفتار به اینترنت نیاز دارد و اتصال ناموفق بود.";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "زمان اتصال سرویس گفتار تمام شد.";
            case SpeechRecognizer.ERROR_NO_MATCH: return "گفتاری تشخیص داده نشد.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "سرویس تشخیص گفتار مشغول است؛ دوباره امتحان کنید.";
            case SpeechRecognizer.ERROR_SERVER: return "خطای سرور سرویس گفتار.";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "سرویس گفتار قطع شد.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "صدایی دریافت نشد.";
            default: return "تشخیص گفتار ناموفق بود (کد " + error + ").";
        }
    }

    private String safeMessage(Throwable e) {
        String m = e == null ? null : e.getMessage();
        return m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
    }

    @PluginMethod
    public void isAvailable(PluginCall call) {
        JSObject out = new JSObject();
        boolean service = false;
        boolean onDevice = false;
        try { service = SpeechRecognizer.isRecognitionAvailable(getContext()); } catch (Throwable ignored) {}
        try { onDevice = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext()); } catch (Throwable ignored) {}
        out.put("available", service || onDevice);
        out.put("serviceAvailable", service);
        out.put("onDeviceAvailable", onDevice);
        out.put("api", Build.VERSION.SDK_INT);
        call.resolve(out);
    }

    @Override
    protected void handleOnDestroy() {
        clearTimeout();
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Throwable ignored) {}
            destroyRecognizer();
        }
        pendingCall = null;
        super.handleOnDestroy();
    }
}
