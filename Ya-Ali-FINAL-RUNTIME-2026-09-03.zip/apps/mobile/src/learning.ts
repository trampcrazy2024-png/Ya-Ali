import type { LanguageBankItem } from '@yaali/database';

export type ReviewRating = 'again' | 'hard' | 'good' | 'easy';
export type ReviewState = { due:number; interval:number; ease:number; reps:number; lapses:number; lastRating:ReviewRating; lastReview:number };
const KEY='yaali_srs_v1';

type Store=Record<string,ReviewState>;
function read():Store { try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch{return {}} }
function write(s:Store){try{localStorage.setItem(KEY,JSON.stringify(s))}catch{}}

export function getReviewState(id:string):ReviewState{
  return read()[id] || {due:0,interval:0,ease:2.3,reps:0,lapses:0,lastRating:'again',lastReview:0};
}

export function reviewItem(id:string,rating:ReviewRating):ReviewState{
  const all=read(); const old=getReviewState(id); const now=Date.now();
  let interval=old.interval; let ease=old.ease; let reps=old.reps; let lapses=old.lapses; let due=now;
  if(rating==='again'){interval=0;lapses+=1;ease=Math.max(1.3,ease-0.2);due=now+10*60*1000;}
  if(rating==='hard'){interval=Math.max(1,Math.round((interval||1)*1.2));ease=Math.max(1.3,ease-0.15);reps+=1;due=now+interval*86400000;}
  if(rating==='good'){interval=interval<1?1:Math.max(2,Math.round(interval*ease));ease=Math.min(3.0,ease+0.05);reps+=1;due=now+interval*86400000;}
  if(rating==='easy'){interval=interval<1?4:Math.max(4,Math.round(interval*ease*1.35));ease=Math.min(3.2,ease+0.15);reps+=1;due=now+interval*86400000;}
  const state={due,interval,ease,reps,lapses,lastRating:rating,lastReview:now}; all[id]=state; write(all); return state;
}

export function getDueItems(items:LanguageBankItem[], now=Date.now()):LanguageBankItem[]{
  const store=read(); return items.filter(x=>(store[x.id]?.due||0)<=now);
}
export function getLearningStats(items:LanguageBankItem[]){
  const store=read(); const now=Date.now(); let due=0,reviewed=0,learned=0; const days=new Set<string>();
  for(const x of items){const s=store[x.id];if(!s)due++;else{reviewed++;if((s.due||0)>now)learned++;else due++;if(s.lastReview)days.add(new Date(s.lastReview).toLocaleDateString('en-CA'));}}
  let streak=0; for(let i=0;i<365;i++){const d=new Date(now-i*86400000).toLocaleDateString('en-CA');if(days.has(d))streak++;else if(i>0)break;}
  return {total:items.length,due,reviewed,learned,streak};
}
export function nextDueText(id:string){const s=getReviewState(id);if(!s.due)return 'جدید';const diff=s.due-Date.now();if(diff<=0)return 'اکنون';if(diff<3600000)return `تا ${Math.ceil(diff/60000)} دقیقه دیگر`;if(diff<86400000)return `تا ${Math.ceil(diff/3600000)} ساعت دیگر`;return `تا ${Math.ceil(diff/86400000)} روز دیگر`;}
