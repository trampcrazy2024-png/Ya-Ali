#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [[ -z "${ANDROID_HOME}" ]]; then echo "ERROR: ANDROID_HOME/ANDROID_SDK_ROOT is not set" >&2; exit 2; fi
export ANDROID_HOME
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
(( NODE_MAJOR >= 20 )) || { echo "ERROR: Node.js 20+ required" >&2; exit 2; }
npm ci
npm run build
npx cap sync android
cd android
[[ -f gradle/wrapper/gradle-wrapper.jar ]] || { echo "ERROR: gradle-wrapper.jar missing. Run ./gradlew wrapper with network access or restore the wrapper JAR." >&2; exit 3; }
./gradlew clean assembleDebug --no-daemon
mkdir -p ../artifacts
cp -f app/build/outputs/apk/debug/app-debug.apk ../artifacts/ya-ali-1.0.0-debug.apk
sha256sum ../artifacts/ya-ali-1.0.0-debug.apk
